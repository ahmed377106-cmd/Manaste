const local = "http://localhost:5000";
const domain = "https://educational-platformback.vercel.app";


export const host = local;