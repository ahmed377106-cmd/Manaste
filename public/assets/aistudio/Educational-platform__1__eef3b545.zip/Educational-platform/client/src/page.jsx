/* eslint-disable react/prop-types */
"use client";

import { useEffect, useState } from "react";
import Header from "./components/ui/Header";
import HeroSection from "./pagesComponents/Home/HeroSection";
import CoursesSection from "./pagesComponents/coursesSection/coursesSection";
import Footer from "./components/ui/Footer";
import FullPageLoading from "./components/ui/FullPageLoading";

export default function Home({ user, tokenState }) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 2000)); 
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <main dir="rtl">
      <div style={{
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}>
        <Header tokenState={tokenState} user={user} />
        <HeroSection />
        <CoursesSection />
        <Footer />
      </div>
      <FullPageLoading loading={loading} />
    </main>
  );
}
