import React from "react";
import FullPageLoading from "../../components/ui/FullPageLoading";
import { useNavigate } from "react-router";

const ErrorPage = ({ user, tokenState, errorMessage = "حدث خطأ ما" }) => {
  const navigate = useNavigate();
  return (
    <>
      <FullPageLoading loading={false} />
      <div className="flex justify-center min-h-screen items-center flex-col" dir="rtl">

        <div className=" text-xl font-semibold text-[rgb(87,255,47)]">
        حدث خطأ ما
        </div>
        <div className=" flex justify-center mt-4">
          <button
            className="bg-[rgb(87,255,47)] text-black font-semibold px-4 py-2 rounded-md hover:bg-[rgb(81,184,55)] transition"
            onClick={() => navigate("./")}
          >
            العودة للصفحة الرئيسية
          </button>
        </div>
      </div>
    </>
  );
};

export default ErrorPage;
