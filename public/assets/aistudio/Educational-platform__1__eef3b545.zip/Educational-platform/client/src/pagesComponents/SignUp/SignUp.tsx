import { useNavigate } from "react-router-dom";
import { useState } from "react";
import styles from "./style.module.scss";
import axios from "axios";
import { Link } from "react-router-dom";
import { X } from "lucide-react";
import { host } from "../../api.js"
import Cookies from 'js-cookie';

export default function SignUp() {
  const navigate = useNavigate();
  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
    passwordRepeat: "",
    year: "", 
    branch: "",
    phone: "",
    fatherPhone: "",
  });
  const [btnDisabled, setBtnDisabled] = useState(false);
  const [errorMessage, setErrorMessage] = useState({
    general: "",
    name: "",
    email: "",
    password: "",
    passwordRepeat: "",
    year: "",
    branch: "",
    phone: "",
    fatherPhone: "",
  });
  const [isLoading, setIsLoading] = useState(
    <>
      <i className="fa-solid fa-angle-left"></i>إنشاء حساب
    </>
  );

  const handleYearChange = (e) => {
    const selectedYear = e.target.value;
    setData({ ...data, year: selectedYear, branch: "" });
  };

  const handleBranchChange = (e) => {
    setData({ ...data, branch: e.target.value });
  };

  const validateForm = () => {
    let isValid = true;
    const errors = {
      name: "",
      email: "",
      password: "",
      passwordRepeat: "",
      year: "",
      branch: "",
      phone: "",
      fatherPhone: "",
    };

    if (data.name.trim() === "") {
      errors.name = "الرجاء إدخال الاسم";
      isValid = false;
    } else if (data.name.length < 3) {
      errors.name = "الاسم يجب أن يكون على الأقل 3 حروف";
      isValid = false;
    }
    if (data.email.trim() === "") {
      errors.email = "الرجاء إدخال البريد الإلكتروني";
      isValid = false;
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
      errors.email = "الرجاء إدخال بريد الكتروني صالح";
      isValid = false;
    }
    if (data.password.trim() === "") {
      errors.password = "الرجاء إدخال كلمة المرور";
      isValid = false;
    } else if (data.password.length < 8) {
      errors.password = "كلمة المرور يجب أن تكون على الأقل 8 حروف";
      isValid = false;
    }
    if (data.passwordRepeat.trim() === "") {
      errors.passwordRepeat = "الرجاء تأكيد كلمة المرور";
      isValid = false;
    } else if (data.password.trim() !== data.passwordRepeat.trim()) {
      errors.passwordRepeat = "كلمة المرور غير متطابقة";
      isValid = false;
    }

    setErrorMessage((prevState) => ({ ...prevState, ...errors }));
    return isValid;
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
        return;
    }
    setBtnDisabled(true);
    setIsLoading(
      <>
        <i className="fa-solid fa-spinner fa-spin"></i>جاري التحقق
      </>
    );

    try {
        const res = await axios.post(`${host}/api/auth/signup`, {
            name: data.name,
            email: data.email,
            password: data.password,
            year: data.year,
            branch: data.branch,
            phone: data.phone,
            fatherPhone: data.fatherPhone,
        });
        if (res.status === 201) {
            
            const { token } = res.data; 
            Cookies.set('token', token, { expires: 4 / 24 }); 
            navigate("/"); 
        }
    } catch (error) {
        setBtnDisabled(false);
        setIsLoading(
          <>
            <i className="fa-solid fa-angle-left"></i>إنشاء حساب
          </>
        );
        const errorMessage = error.response?.data?.msg || "An error occurred";      
        setErrorMessage((prevState) => ({ ...prevState, general: errorMessage }));
    }
};

  const clearError = (field) => {
    setErrorMessage((prevState) => ({ ...prevState, [field]: "" }));
  };

  return (
    <main>
      <div className={styles.SignUpMain}>
        <form onSubmit={submit} dir="rtl">
          <h2>انشاء حساب جديد</h2>
          {errorMessage.general && (
            <div
              style={{ display: "flex", flexDirection: "row-reverse", paddingTop: "10px", paddingBottom: "10px"}}
              className={styles.SignUpError}
            >
              <X
                style={{ cursor: "pointer" }}
                onClick={() => clearError("general")}
              />
              {errorMessage.general}
            </div>
          )}

          {/* Existing Fields */}
          <input
            placeholder="الاسم"
            onChange={(e) => setData({ ...data, name: e.target.value })}
            style={{ border: errorMessage.name && "1px solid var(--red)" }}
          />
          <input
            placeholder="البريد الإلكتروني"
            onChange={(e) => setData({ ...data, email: e.target.value })}
            style={{ border: errorMessage.email && "1px solid var(--red)" }}
          />
          <input
            placeholder="كلمة المرور"
            onChange={(e) => setData({ ...data, password: e.target.value })}
            style={{ border: errorMessage.password && "1px solid var(--red)" }}
          />
          <input
            placeholder="تأكيد كلمة المرور"
            onChange={(e) =>
              setData({ ...data, passwordRepeat: e.target.value })
            }
            style={{
              border: errorMessage.passwordRepeat && "1px solid var(--red)",
            }}
          />

          {/* New Year Field with Options */}
          <select
            value={data.year}
            onChange={handleYearChange}
            className={errorMessage.year ? "error" : ""}
          >
            <option value="">اختر السنه الدراسيه</option>
            <option value="First">الصف الاول</option>
            <option value="Second">الصف الثاني</option>
            <option value="Third">الصف الثالث</option>
          </select>

          <select
            value={data.branch}
            onChange={handleBranchChange}
            className={errorMessage.branch ? "error" : ""}
          >
            <option value="">اختر القسم</option>
            {data.year === "First" ? (
              <>
                <option value="Scientific">علمي</option>
                <option value="Literary">ادبي</option>
              </>
            ) : (
              <>
                <option value="Scientific_Sciences">علمي علوم</option>
                <option value="Math_Science">علمي رياضه</option>
                <option value="Literary">ادبي</option>
              </>
            )}
          </select>

          {/* New Phone Fields */}
          <input
            placeholder="رقم الهاتف"
            onChange={(e) => setData({ ...data, phone: e.target.value })}
            style={{ border: errorMessage.phone && "1px solid var(--red)" }}
          />
          <input
            placeholder="رقم ولي الامر"
            onChange={(e) => setData({ ...data, fatherPhone: e.target.value })}
            style={{
              border: errorMessage.fatherPhone && "1px solid var(--red)",
            }}
          />

          <button disabled={btnDisabled} type="submit" dir="ltr">
            {isLoading}
          </button>
          <p
            style={{
              textAlign: "center",
              marginTop: "20px",
              color: "var(--txt)",
            }}
          >
            لديك حساب؟{" "}
            <Link to="/login" style={{ color: "var(--primary)" }}>
              تسجيل الدخول
            </Link>
          </p>
        </form>
      </div>
    </main>
  );
}
