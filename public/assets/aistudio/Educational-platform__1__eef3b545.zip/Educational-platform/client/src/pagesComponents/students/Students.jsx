/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { host } from "../../api";
import Header from "../../components/ui/Header";
import FullPageLoading from "../../components/ui/FullPageLoading";
import StudentCard from "../../components/ui/StudentCard";

const Students = ({ user, tokenState }) => {
  const [students, setStudents] = useState([]);
  const [filteredStudents, setFilteredStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(""); // State to hold the search query

  const fetchStudents = async () => {
    const token = Cookies.get("token");

    try {
      const response = await axios.get(`${host}/api/cart/all`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setStudents(response.data);
      setFilteredStudents(response.data); // Initially, show all students
    } catch (error) {
      console.error("Error fetching students:", error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  useEffect(() => {
    if (searchQuery === "") {
      setFilteredStudents(students); // Show all students if search query is empty
    } else {
      const filtered = students.filter(
        (student) =>
          student.user.name.toLowerCase().includes(searchQuery.toLowerCase()) || // Filter students by name
          student.user.email.toLowerCase().includes(searchQuery.toLowerCase()) // Filter students by email
      );
      setFilteredStudents(filtered);
    }
  }, [searchQuery, students]); // Update filtered students when search query changes

  const handleFilterClick = (status) => {
    if (status === "الكل") {
      setFilteredStudents(students); // If "الكل" is selected, show all students
    }
  };

  return (
    <>
      <Header user={user} tokenState={tokenState} />
      <FullPageLoading loading={loading} />
      <div className="p-6 mt-20" dir="rtl">
        <h2 className="text-2xl font-semibold mb-4 text-[rgb(87,255,47)]">
          الطلاب المسجلين
        </h2>

        {/* Search input */}
        <div className="w-full container flex justify-center items-center">
          <input
            type="text"
            placeholder="بحث بالاسم أو البريد الإلكتروني"
            className="p-2 border border-white/30 rounded-md mb-4 focus:border-[rgb(87,255,47)]" // Updated to focus border color
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="w-full flex justify-center relative z-10">
          {!loading && filteredStudents.length === 0 ? (
            <div className="flex items-center justify-center h-screen text-xl font-semibold text-gray-500">
              لا توجد طلاب مسجلين
            </div>
          ) : (
            <ul className="flex flex-col space-y-5 container">
              {filteredStudents.map(({ user, courses, _id }) => (
                <li key={_id}>
                  <StudentCard
                    student={user}
                    courses={courses}
                    cartId={_id}
                    fetchStudents={fetchStudents} // Pass fetchStudents as prop
                  />
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </>
  );
};

export default Students;
