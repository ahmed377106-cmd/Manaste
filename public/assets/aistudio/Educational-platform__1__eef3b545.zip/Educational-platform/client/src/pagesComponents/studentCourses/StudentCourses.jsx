/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import Cookies from "js-cookie";
import Header from "../../components/ui/Header.jsx";
import { host } from "../../api.js";
import MyCourseCard from "../../components/ui/MyCourseCard.jsx"; 
import FullPageLoading from "../../components/ui/FullPageLoading.jsx"; 
import { motion } from "framer-motion"; 

const StudentCourses = ({ user, tokenState }) => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    const fetchCourses = async () => {
      const token = Cookies.get("token");
  
      try {
        const response = await fetch(`${host}/api/cart`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });
  
        if (!response.ok) {
          const errorMessage = await response.text();
          setError(errorMessage);
          return;
        }
  
        const data = await response.json();
        if (data.courses && Array.isArray(data.courses)) {
          // Filter courses only if course is not null and has the 'suspend' property
          const availableCourses = data.courses.filter(courseItem => 
            courseItem.course && 
            !courseItem.course.suspend
          );
          setCourses(availableCourses);
        } else {
          setCourses([]);
        }
      } catch (err) {
        console.error("Fetch error:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
  
    fetchCourses();
  }, []);
  
  return (
    <div className="min-h-screen p-6 md:p-8" dir="rtl">
      <Header tokenState={tokenState} user={user} />
      {loading && <FullPageLoading loading={loading} />} 
      <div className="mx-auto max-w-7xl mt-20">
        <div className={`${courses.length ? "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4" : "flex justify-center items-center mt-52"}`}>
          {courses.length > 0 ? (
            courses.map((courseItem) => {
              const { course, status, _id } = courseItem;
              return (
                <motion.div
                  key={_id}
                  initial={{ opacity: 0, scale: 0.9 }} 
                  animate={{ opacity: 1, scale: 1 }} 
                  transition={{ duration: 0.3 }} 
                >
                  <MyCourseCard 
                    course={course} 
                    status={status} 
                    teacherImg={course.teacherImg} 
                    suspend={course.suspend}
                  />
                </motion.div>
              );
            })
          ) : (
            !loading && (
              <div className="text-center text-white p-6 border-zinc-800 bg-zinc-900/50 rounded-lg shadow-md">
                <p className="text-xl font-semibold mb-4">انت غير مشترك فى اى كورس</p>
                <button
                  onClick={() => window.location.href = "/courses"}
                  className="px-6 py-2 bg-[rgb(87,255,47)] text-black font-bold rounded transition duration-200"
                >
                  احجز كورس
                </button>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentCourses;
