/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import AdminCard from "../../components/ui/AdminCard";
import { host } from "../../api";
import Header from "../../components/ui/Header";
import FullPageLoading from "../../components/ui/FullPageLoading";
import AddManagerModal from "../../components/ui/AddManagerModal";

const Managers = ({ user, tokenState }) => {
  const [admins, setAdmins] = useState([]);
  const [filteredAdmins, setFilteredAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchAdmins = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${host}/api/auth/getadmins`);
      const data = await response.json();

      if (Array.isArray(data)) {
        setAdmins(data);
        setFilteredAdmins(data);
      } else {
        console.error("Invalid admins data:", data);
      }
    } catch (error) {
      console.error("Error fetching admins:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdmins();
  }, []);

  useEffect(() => {
    const filtered = admins.filter((admin) => {
      const lowerSearchQuery = searchQuery.toLowerCase();
      return (
        admin.name.toLowerCase().includes(lowerSearchQuery) ||
        admin.email.toLowerCase().includes(lowerSearchQuery) ||
        admin.role.toLowerCase().includes(lowerSearchQuery)
      );
    });

    setFilteredAdmins(filtered);
  }, [searchQuery, admins]);

  return (
    <>
      <Header user={user} tokenState={tokenState} />
      <FullPageLoading loading={loading} />
      <div className="p-6 mt-20" dir="rtl">
        <h2 className="text-2xl font-semibold mb-4 text-[rgb(87,255,47)]">
          إدارة المشرفين
        </h2>
        <div className="flex justify-center items-center mb-4">
          <input
            type="text"
            placeholder="بحث بالاسم، البريد الإلكتروني أو الدور"
            className="p-2 border border-gray-300 rounded-md focus:border-[rgb(87,255,47)] w-full max-w-md"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="w-full flex justify-center">
          <button
            className="bg-[rgb(87,255,47)] text-black font-semibold px-4 py-2 rounded-md hover:bg-[rgb(81,184,55)] transition"
            onClick={() => setIsModalOpen(true)}
          >
            أضافة ادارى{" "}
          </button>
        </div>

        <div className="w-full flex justify-center relative z-10 mt-6">
          {!loading && filteredAdmins.length === 0 ? (
            <div className="flex items-center justify-center h-screen text-xl font-semibold text-gray-500">
              لا توجد مشرفين
            </div>
          ) : (
            <ul className="flex flex-col space-y-5 container">
              {filteredAdmins.map((admin) => (
                <li key={admin._id}>
                  <AdminCard
                    admin={admin}
                    fetchAdmins={fetchAdmins}
                    user={user}
                  />
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {isModalOpen && (
        <AddManagerModal
          onClose={() => setIsModalOpen(false)}
          onSave={fetchAdmins}
        />
      )}
    </>
  );
};

export default Managers;
