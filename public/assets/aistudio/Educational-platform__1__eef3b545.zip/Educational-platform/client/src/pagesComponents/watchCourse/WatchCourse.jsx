/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import VideoCard from "../../components/ui/VideoCard";
import Header from "../../components/ui/Header";
import FullPageLoading from "../../components/ui/FullPageLoading";
import { host } from "../../api.js";

const WatchCourse = ({ user, tokenState }) => {
  const [selectedEpisode, setSelectedEpisode] = useState(1);
  const [selectedEpisodeLink, setSelectedEpisodeLink] = useState(null);
  const [courseDetails, setCourseDetails] = useState(null);
  const [loading, setLoading] = useState(true); // New loading state
  const { id } = useParams();

  useEffect(() => {
    if (!id) return;

    const fetchCourseDetails = async () => {
      setLoading(true);
      try {
        const response = await fetch(`${host}/api/courses/${id}`);
        if (!response.ok) throw new Error("Failed to fetch course details");
        const data = await response.json();
        setCourseDetails(data);
        setSelectedEpisodeLink(data.listOfLec[0]);
      } catch (error) {
        console.error("Error fetching course data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCourseDetails();
  }, [id]);

  if (loading) {
    return <FullPageLoading loading={loading} />;
  }

  if (!courseDetails) {
    return <div>Loading...</div>;
  }

  const { listOfLec, subject, teacher, teacherImg, description } =
    courseDetails;

  return (
    <div className="min-h-screen text-white p-4 md:p-6" dir="rtl">
      <Header user={user} tokenState={tokenState} />
      <div className="max-w-6xl mx-auto space-y-6 mt-20">
        {/* Course Information */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-[#57ff2f]">{subject}</h1>
          <p className="text-gray-400">{description}</p>
          <div className="flex items-center justify-center space-x-2">
            <img
              src={teacherImg}
              alt={`${teacher}'s avatar`}
              className="w-12 h-12 rounded-full ml-2"
            />
            <span className="text-lg font-medium">{teacher}</span>
          </div>
        </div>

        {/* Video Player Area */}
        <VideoCard episodeLink={selectedEpisodeLink} />

        {/* Episodes Section */}
        <div className="space-y-4" dir="rtl">
          <h2 className="text-2xl text-center">المحاضرات</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
            {listOfLec.map((link, index) => (
              <button
                key={index}
                className={`py-2 bg-[rgb(87,255,47)] text-black font-semibold rounded-lg hover:bg-[rgba(89,255,47,0.56)] duration-500 ${
                  selectedEpisode === index + 1
                    ? "ring-2 ring-[rgb(59,128,42)]"
                    : ""
                }`}
                onClick={() => {
                  setSelectedEpisode(index + 1);
                  setSelectedEpisodeLink(link);
                }}
              >
                {`المحاضرة ${index + 1}`}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WatchCourse;

