/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import { host } from "../../api.js";
import AdminCourseCard from "../../components/ui/AdminCourseCard.jsx";
import EditCourseModal from "../../components/ui/EditCourseModal.jsx";
import AddCourseModal from "../../components/ui/AddCourseModal.jsx";
import LectureCourseModal from "../../components/ui/LectureCourseModal.jsx";
import Header from "../../components/ui/Header";
import FullPageLoading from "../../components/ui/FullPageLoading";
import ConfirmationModal from "../../components/ui/ConfirmationModal.jsx"; 

const AdminCourses = ({ user, tokenState }) => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isLectureModalOpen, setIsLectureModalOpen] = useState(false);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
  const [actionType, setActionType] = useState("add");

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${host}/api/courses`);
      if (!response.ok) throw new Error("Failed to fetch courses");
      const data = await response.json();
      setCourses(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddCourse = () => {
    setActionType("add");
    setSelectedCourse(null);
    setIsAddModalOpen(true);
  };

  const handleEditCourse = (course) => {
    setActionType("edit");
    setSelectedCourse(course);
    setIsEditModalOpen(true);
  };

  const handleDeleteCourse = (courseId, courseName, teacherName) => {
    setSelectedCourse({ id: courseId, name: courseName, teacher: teacherName });
    setIsConfirmDeleteOpen(true);
  };

  const confirmDeleteCourse = async () => {
    try {
      await fetch(`${host}/api/courses/${selectedCourse.id}`, {
        method: "DELETE",
      });
      setCourses(courses.filter(course => course._id !== selectedCourse.id));
      setSelectedCourse(null);
    } catch (err) {
      setError("Failed to delete course");
    } finally {
      setIsConfirmDeleteOpen(false);
    }
  };

  const handleConfirmDeleteClose = () => {
    setIsConfirmDeleteOpen(false);
    setSelectedCourse(null);
  };

  const handleSuspendCourse = async (courseId) => {
    try {
      await fetch(`${host}/api/courses/${courseId}/suspend`, {
        method: "PATCH",
      });
      fetchCourses();
    } catch (err) {
      setError("Failed to suspend course");
    }
  };

  const handleEditModalClose = () => {
    setIsEditModalOpen(false);
    fetchCourses();
  };

  const handleAddModalClose = () => {
    setIsAddModalOpen(false);
    fetchCourses();
  };

  const handleLectureModalClose = () => {
    setIsLectureModalOpen(false);
  };

  const handleViewLectures = (course) => {
    setSelectedCourse(course);
    setIsLectureModalOpen(true);
  };

  const handleAddLecture = async (courseId, newLectureLink) => {
    if (!newLectureLink) return; // Guard clause if the link is empty

    try {
      const response = await fetch(`${host}/api/courses/${courseId}/add-lecture`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ lectureLink: newLectureLink }),
      });

      if (!response.ok) throw new Error('Failed to add lecture');

      // Fetch updated courses after adding a lecture
      fetchCourses();
    } catch (error) {
      console.error(error);
    }
  };

  const handleSave = (updatedCourse) => {
    console.log("Course updated:", updatedCourse);
  };

  return (
    <div className="min-h-screen p-6 md:p-8" dir="rtl">
      <Header user={user} tokenState={tokenState} />
      <header className="flex justify-between mt-20 items-center mb-4">
        <h1 className="font-bold text-[rgb(87,255,47)] text-3xl">أدارة الكورسات</h1>
        <button disabled={user.role === "Manager"} onClick={handleAddCourse} className={`${user.role === "Manager" ? "opacity-50 cursor-not-allowed":""} bg-[rgb(87,255,47)] text-black font-semibold px-4 py-2 rounded-md`}>اضافة كورس</button>
      </header>
      
      <FullPageLoading loading={loading} />

      {error && <p>Error: {error}</p>}
      
      {!loading && !error && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {courses.map(course => (
            <AdminCourseCard
              key={course._id}
              course={course}
              onEdit={() => handleEditCourse(course)}
              onSuspend={() => handleSuspendCourse(course._id)}
              onDelete={() => handleDeleteCourse(course._id, course.subject, course.teacher)} // Pass course and teacher names for confirmation
              onViewLectures={() => handleViewLectures(course)}
              userRole={user.role}
            />
          ))}
        </div>
      )}
      
      {isEditModalOpen && (
        <EditCourseModal 
          onClose={handleEditModalClose}
          course={selectedCourse}
          actionType={actionType}
          onSave={handleSave}
        />
      )}

      {isAddModalOpen && (
        <AddCourseModal 
          onClose={handleAddModalClose}
          onSave={handleSave} 
        />
      )}

      {isLectureModalOpen && (
        <LectureCourseModal 
          open={isLectureModalOpen}
          onClose={handleLectureModalClose}
          course={selectedCourse}
          onAddLecture={handleAddLecture} // Pass the function here
        />
      )}

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={isConfirmDeleteOpen}
        onClose={handleConfirmDeleteClose}
        onConfirm={confirmDeleteCourse}
        courseName={selectedCourse ? selectedCourse.name : ""}
        teacherName={selectedCourse ? selectedCourse.teacher : ""}
      />
    </div>
  );
};

export default AdminCourses;
