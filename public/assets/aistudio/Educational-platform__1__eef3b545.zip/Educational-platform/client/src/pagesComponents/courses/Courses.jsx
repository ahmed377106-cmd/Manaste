/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import Header from "../../components/ui/Header";
import { host } from "../../api.js";
import CourseCard from "../../components/ui/CourseCard.jsx"; 
import FullPageLoading from "../../components/ui/FullPageLoading"; 
import CourseDetailsModal from "../../components/ui/CourseDetailsModal.jsx"; 
import Cookies from "js-cookie";
import { useNavigate } from "react-router";

const Courses = ({ user, tokenState }) => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [redirectMessage, setRedirectMessage] = useState(""); 
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const response = await fetch(`${host}/api/courses`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch courses");
        }

        const data = await response.json();
        setCourses(data); 
      } catch (err) {
        setError(err.message); 
      } finally {
        setLoading(false); 
      }
    };

    fetchCourses();
  }, []);

  const handleOpenModal = (course) => {
    const token = Cookies.get("token"); 
    if (!token) {
      setRedirectMessage("يجب تسجيل الدخول أولا"); 
      setTimeout(() => {
        navigate("/login"); 
      }, 3000);
      return; 
    }

    setSelectedCourse(course);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setSelectedCourse(null);
    setIsModalOpen(false);
  };

  // Filter courses to exclude those that are suspended
  const availableCourses = courses.filter(course => !course.suspend);

  return (
    <div className="min-h-screen p-6 md:p-8" dir="rtl">
      <Header tokenState={tokenState} user={user} />
      {loading && <FullPageLoading loading={loading} />} 
      <div className="mx-auto max-w-7xl mt-20">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {error && <p>Error: {error}</p>}
          {availableCourses.length > 0 ? (
            availableCourses.map((courseItem) => {
              return (
                <CourseCard 
                  key={courseItem._id} 
                  courseItem={courseItem} 
                  buttonLabel="أحجز الان"
                  onButtonClick={() => handleOpenModal(courseItem)}
                  userRole={user?.role || "Student"}
                />
              );
            })
          ) : (
            !loading && <p className="text-white">No courses available.</p>
          )}
        </div>
      </div>

      {redirectMessage && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <p className="text-white text-2xl">{redirectMessage}</p>
        </div>
      )}

      {/* Modal for course details */}
      {isModalOpen && selectedCourse && (
        <CourseDetailsModal course={selectedCourse} onClose={handleCloseModal} userId={user._id} />
      )}
    </div>
  );
};

export default Courses;
