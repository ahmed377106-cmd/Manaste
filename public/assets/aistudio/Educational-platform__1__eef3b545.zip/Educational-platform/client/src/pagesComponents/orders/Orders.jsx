/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { host } from "../../api";
import OrderCard from "../../components/ui/OrderCard";
import Header from "../../components/ui/Header";
import FullPageLoading from "../../components/ui/FullPageLoading";

const Orders = ({ user, tokenState }) => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchCourses = async () => {
    const token = Cookies.get("token");
  
    try {
      const response = await axios.get(`${host}/api/cart/waiting`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setCourses(response.data);
    } catch (error) {
      if (error.response && error.response.status === 404) {
        setCourses([]); // Set courses to an empty array if 404 is returned
      } else {
        console.error("Error fetching courses:", error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  const handleAccept = async (cartId, courseId, userId) => {
    const token = Cookies.get("token");
    const data = {
      courseId,
      cartId,
      userId,
    };

    try {
      await axios.patch(`${host}/api/cart/accept`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      fetchCourses(); // Refresh courses after accepting
    } catch (error) {
      console.error("Error accepting course:", error.message);
    }
  };

  const handleReject = async (cartId, courseId, userId) => {
    const token = Cookies.get("token");
    const data = {
      courseId,
      cartId,
      userId,
    };

    try {
      await axios.patch(`${host}/api/cart/reject`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      fetchCourses(); // Refresh courses after rejecting
    } catch (error) {
      console.error("Error rejecting course:", error.message);
    }
  };

  return (
    <>
      <Header user={user} tokenState={tokenState} />
      <FullPageLoading loading={loading} />

      <div className="p-6 mt-20" dir="rtl">
        <h2 className="text-2xl font-semibold mb-4 text-[rgb(87,255,47)]">
          الدورات في حالة الانتظار
        </h2>

        {!loading && courses.length === 0 ? (
          <div className="flex items-center justify-center h-screen text-xl font-semibold text-gray-500">
            لا توجد كورسات في حالة الانتظار
          </div>
        ) : (
          <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 container">
            {courses.map(({ course, cartId, user }) => (
              <li key={cartId}>
                <OrderCard
                  courseItem={course}
                  user={user}
                  cartId={cartId}
                  onAccept={() => handleAccept(cartId, course._id, user._id)}
                  onReject={() => handleReject(cartId, course._id, user._id)}
                />
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
};

export default Orders;
