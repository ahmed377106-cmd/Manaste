import { useNavigate } from "react-router-dom";
import { useState } from "react";
import styles from "./style.module.scss";
import axios from "axios";
import { Link } from "react-router-dom";
import { X } from "lucide-react";
import { host } from "../../api.js";
import Cookies from 'js-cookie';

export default function Login() {
  const navigate = useNavigate();
  const [data, setData] = useState({
    email: "",
    password: "",
  });
  const [btnDisabled, setBtnDisabled] = useState(false);
  const [errorMessage, setErrorMessage] = useState({
    general: "",
    email: "",
    password: "",
  });
  const [isLoading, setIsLoading] = useState(
    <>
      <i className="fa-solid fa-angle-left"></i>تسجيل الدخول
    </>
  );

  const validateForm = () => {
    let isValid = true;
    const errors = {
      email: "",
      password: "",
    };

    if (data.email.trim() === "") {
      errors.email = "الرجاء إدخال البريد الإلكتروني";
      isValid = false;
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
      errors.email = "الرجاء إدخال بريد الكتروني صالح";
      isValid = false;
    }
    if (data.password.trim() === "") {
      errors.password = "الرجاء إدخال كلمة المرور";
      isValid = false;
    } else if (data.password.length < 8) {
      errors.password = "كلمة المرور يجب أن تكون على الأقل 8 حروف";
      isValid = false;
    }

    setErrorMessage((prevState) => ({ ...prevState, ...errors }));
    return isValid;
  };

  const submit = async (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    if (!validateForm()) {
        return;
    }
    setBtnDisabled(true);
    setIsLoading(
      <>
        <i className="fa-solid fa-spinner fa-spin"></i>جاري التحقق
      </>
    );

    try {
      const res = await axios.post(`${host}/api/auth/login`, {
        email: data.email,
        password: data.password,
      });
      if (res.status === 200) {
        const { token } = res.data;
        Cookies.set('token', token, { expires: 4 / 24 });
        navigate("/");
      }
    } catch (error) {
      setBtnDisabled(false);
      setIsLoading(
        <>
          <i className="fa-solid fa-angle-left"></i>تسجيل الدخول
        </>
      );
      const errorMessage = error.response.data.msg || "An error occurred";
      setErrorMessage((prevState) => ({ ...prevState, general: errorMessage }));
    }
  };

  const clearError = (field: string) => {
    setErrorMessage((prevState) => ({ ...prevState, [field]: "" }));
  };

  return (
    <main>
      <div className={styles.LoginMain}>
        <form onSubmit={submit} dir="rtl">
          <h2>تسجيل الدخول</h2>
          {errorMessage.general && (
            <div
              style={{ display: "flex", flexDirection: "row-reverse", paddingTop: "10px", paddingBottom: "10px"}}
              className={styles.LoginError}
            >
              <X
                style={{ cursor: "pointer" }}
                onClick={() => clearError("general")}
              />
              {errorMessage.general}
            </div>
          )}
          <input
            placeholder="البريد الإلكتروني"
            onChange={(e) => setData({ ...data, email: e.target.value })}
            style={{ border: errorMessage.email && "1px solid var(--red)" }}
          />
          <input
            placeholder="كلمة المرور"
            type="password"
            onChange={(e) => setData({ ...data, password: e.target.value })}
            style={{ border: errorMessage.password && "1px solid var(--red)" }}
          />
          <button  disabled={btnDisabled} type="submit" style={{ textAlign: "right" }} dir="">
            {isLoading}
          </button>
          <p
            style={{
              textAlign: "center",
              marginTop: "20px",
              color: "var(--txt)",
            }}
          >
            ليس لديك حساب؟{" "}
            <Link to="/signup" style={{ color: "var(--primary)" }}>
              إنشاء حساب
            </Link>
          </p>
        </form>
      </div>
    </main>
  );
}
