/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */

"use client";

import { Link, useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";
import styles from "./style.module.scss";
import { useEffect, useRef, useState } from "react";
import { Bell, ChevronLeft } from "lucide-react";
import axios from "axios";
import Cookies from "js-cookie";
import {
  notificationBoxComponent,
  ResponsieNotificationComponent,
} from "./notificationBoxComponent";
export default function Header({ user }) {
  const navigate = useNavigate();
  const [userdata, setUserData] = useState({
    name: "",
    email: "",
    year: "",
    _id: "",
    branch: "",
    phone: "",
    fatherPhone: "",
    createdAt: "",
  });

  const [notifications, setNotifications] = useState([]);
  const [notificationCount, SetnotificationCount] = useState(0);
  const [listOpen, setListOpen] = useState(false);
  const [isLoginIn, setIsLoginIn] = useState(true);

  const logout = async () => {
    // Remove the token and reset user data
    Cookies.remove("token");
    setUserData({
      name: "",
      email: "",
      year: "",
      _id: "",
      branch: "",
      phone: "",
      fatherPhone: "",
      createdAt: "",
    });
    setIsLoginIn(false);

    navigate("/", { replace: true });

    window.location.reload();
  };

  useEffect(() => {
    if (user) {
      setUserData(user);
      setIsLoginIn(true);
    } else {
      setIsLoginIn(false);
      setUserData({
        name: "",
        email: "",
        year: "",
        _id: "",
        branch: "",
        phone: "",
        fatherPhone: "",
        createdAt: "",
      });
    }
  }, [user]);
  const [notificationListOpen, setNotificationListOpen] = useState(false);

  const openNotificationListButton = useRef(null);
  const responseiveList = useRef(null);
  const responseListBtn  = useRef(null);
  useEffect(() => {
    const notificationList = document.getElementById("notificationList");

    document.addEventListener("click", (e ) => {
      if (
        notificationList &&
        !notificationList?.contains(e.target) &&
        !openNotificationListButton?.current?.contains(e.target)
      ) {
        setNotificationListOpen(false);
        // console.log('clicked outside');
      }

      if (
        responseiveList.current &&
        !responseiveList?.current?.contains(e.target) &&
        !responseListBtn?.current?.contains(e.target)
      ) {
        setListOpen(false);
      }
    });
    return () => {
      document.removeEventListener("click", () => {
        // console.log(notificationBoxRef)
      });
    };
  }, []);

  const [responsiveNotificationList, setResponsiveNotificationList] =
    useState(false);
  const handleResponsiveNotificationListOpen = async () => {
    if (responsiveNotificationList) {
      setResponsiveNotificationList(false);
    } else {
      setResponsiveNotificationList(true);
    }
    try {
      const response = await axios.post("/api/notification");
      console.log(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <header className={styles.header} dir="rtl">
      <div className={styles.right}>
        <Link className={styles.logo} to="/">
          منصتى
        </Link>
        <nav className={styles.navigation}>
          <Link to={"/"}>الصفحة الرئيسية</Link>
          {user && user?.role != "Student" ? (
            <Link to={"/coursesdashboard"}>كورساتنا</Link>
          ) : (
            <Link to={"/courses"}>كورساتنا</Link>
          )}
          {user?.role != "Student" && isLoginIn ? (
            <>
              <Link to={`/students`}>الطلاب</Link>
              <Link to={`/managers`}>المديرين</Link>
            </>
          ) : isLoginIn ? (
            <Link to={`/courses/${user?._id}`}>كورساتى</Link>
          ) : null}
          {user?.role != "Student" && isLoginIn ? (
            <Link to={`/orders`}>الطلبات</Link>
          ) : (
            <Link to="/">تواصل معنا</Link>
          )}
        </nav>
      </div>
      <div className={styles.account}>
        {isLoginIn ? (
          <div className={styles.accountBox}>
            <Link to={"/"}>
              حسابي
              <img
                src={
                  "https://i.pinimg.com/736x/90/de/25/90de257fdac14d35d66a81ab8e282cad.jpg"
                }
                alt={"profile pic"}
                width={30}
                height={30}
              />
            </Link>
            <Link
              ref={openNotificationListButton}
              onClick={logout}
              style={{ marginLeft: "10px", color: "red" }}
              className={styles.cart}
              to={""}
            >
              <LogOut />
              {notificationCount > 0 && (
                <span>
                  {notificationCount > 99 ? "99+" : notificationCount}
                </span>
              )}
            </Link>
          </div>
        ) : (
          <>
            <Link to={"/login"}>تسجيل الدخول</Link>
            <Link to={"/signup"}>تسجيل</Link>
          </>
        )}
        {/* {notificationBoxComponent({
          isOpen: notificationListOpen,
          notifications: notifications,
        })} */}
        <label ref={responseListBtn} className={styles.hamburger}>
          <input
            type="checkbox"
            checked={listOpen}
            onChange={(e ) => setListOpen(e.target.checked)}
          />
          <svg viewBox="0 0 32 32">
            <path
              className={`${styles.line} ${styles.lineTopBottom}`}
              d="M27 10 13 10C10.8 10 9 8.2 9 6 9 3.5 10.8 2 13 2 15.2 2 17 3.8 17 6L17 26C17 28.2 18.8 30 21 30 23.2 30 25 28.2 25 26 25 23.8 23.2 22 21 22L7 22"
            ></path>
            <path className={styles.line} d="M7 16 27 16"></path>
          </svg>
        </label>
      </div>
      <div
        ref={responseiveList}
        className={styles.list}
        style={{
          height: isLoginIn
            ? listOpen
              ? responsiveNotificationList
                ? "620px"
                : "455px"
              : "0px"
            : listOpen
            ? "325px"
            : "0px",
          opacity: listOpen ? 1 : 0,
        }}
      >
        {isLoginIn && (
          <div
            className={styles.accountBox}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <div
              style={{
                display: "flex",
                width: "100%",
                flexDirection: "row-reverse",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <div className={styles.btnsHolder}>
                <div
                  onClick={handleResponsiveNotificationListOpen}
                  className={styles.notificationBox}
                >
                  <Bell />
                  {notificationCount > 0 && (
                    <span>
                      {notificationCount > 99 ? "99+" : notificationCount}
                    </span>
                  )}
                </div>
              </div>
              <div className={styles.accountInfo}>
                <div>
                  <h3>مرحبا {userdata.name}</h3>
                  <p>
                    نورتنا في{" "}
                    {new Date(userdata.createdAt).toLocaleDateString("ar-EG", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>
                </div>
                <img
                  src={
                    "https://i.pinimg.com/736x/90/de/25/90de257fdac14d35d66a81ab8e282cad.jpg"
                  }
                  width={50}
                  height={50}
                  alt=""
                />
              </div>
            </div>
            <ResponsieNotificationComponent
              isOpen={responsiveNotificationList}
              notifications={notifications}
            />
          </div>
        )}
        <div className={styles.listNavigation}>
          <Link to="/">
            <ChevronLeft /> الصفحة الرئيسية
          </Link>
          {user?.role != "Student" && isLoginIn ? (
            <Link to={`/orders`}>
              <ChevronLeft />
              الطلبات
            </Link>
          ) : (
            <Link to="/">
              <ChevronLeft /> تواصل معنا
            </Link>
          )}

          {user?.role != "Student" && isLoginIn ? (
            <Link to={"/coursesdashboard"}>
              <ChevronLeft />
              كورساتنا
            </Link>
          ) : (
            <Link to={"/courses"}>
              <ChevronLeft />
              كورساتنا
            </Link>
          )}
          {isLoginIn ? (
            <>
              {user?.role != "Student" ? (
                <>
                  <Link to={`/students`}>
                    <ChevronLeft />
                    الطلاب
                  </Link>
                  <Link to={`/managers`}>
                    <ChevronLeft />
                    المديرين
                  </Link>
                </>
              ) : (
                <Link to={`/courses/${user?._id}`}>
                  <ChevronLeft />
                  كورساتى
                </Link>
              )}
              <Link
                onClick={logout}
                to="/"
                style={{ color: "var(--red)" }}
                onMouseEnter={(e ) => {
                  e.target.style.outline = "1px solid var(--red)";
                }}
                onMouseLeave={(e ) => {
                  e.target.style.outline = "none";
                }}
              >
                <ChevronLeft />
                تسجيل خروج
              </Link>
            </>
          ) : (
            <>
              <Link to="/login">
                <ChevronLeft /> تسجيل الدخول
              </Link>
              <Link
                onMouseEnter={(e ) => {
                  e.target.style.outline = "1px solid var(--txtH)";
                }}
                onMouseLeave={(e ) => {
                  e.target.style.outline = "none";
                }}
                to="/signup"
              >
                <ChevronLeft /> انشاء حساب
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
