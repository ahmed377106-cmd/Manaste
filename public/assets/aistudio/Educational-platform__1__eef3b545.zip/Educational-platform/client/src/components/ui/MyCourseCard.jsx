/* eslint-disable react/prop-types */
import { useNavigate } from "react-router";

const MyCourseCard = ({ course, status, teacherImg, suspend }) => {
  const navigate = useNavigate();
  const handleClick = () => {
    if (status === "Accepted") {
      navigate(`/watch/${course._id}`);
    }
  };

  return (
    <div
      dir="rtl"
      className="group relative overflow-hidden border border-zinc-800 bg-zinc-900/50 transition-all hover:border-zinc-500 hover:-translate-y-1 rounded-lg duration-500"
    >
      <div className="p-4 text-center">
        <h3 className="mb-1 text-lg font-medium text-[rgb(87,255,47)]">
          {course.subject}
        </h3>
        <p className="mb-2 text-lg font-bold text-white">{course.teacher}</p>
        <p className="mb-1 text-md text-zinc-400">
          {course.year == "First" ? "الصف الاول الثانوى" : ""}{" "}
          {course.year == "Second" ? "الصف الثانى الثانوى" : ""}{" "}
          {course.year == "Third" ? "الصف الثالث الثانوى" : ""}
        </p>
        <p className="mb-2 text-sm text-zinc-400">
          {course.term == "First" ? "الفصل الدراسى الاول" : ""}{" "}
          {course.term == "Second" ? "الفصل الدراسى الثانى" : ""}
        </p>

        <div className="aspect-square overflow-hidden">
          <img
            src={teacherImg}
            alt={`${course.teacher}'s image`}
            className="object-cover w-full h-full"
          />
        </div>
        {course.listOfLec.length == 0 ? (
          <p className="mt-4 text-zinc-400">لا توجد محاضرات الان لعرضها</p>
        ) : (
          <p className="mt-4 text-zinc-400">
            عدد المحاضرات : {course.listOfLec.length}
          </p>
        )}

        <button
          onClick={handleClick}
          className={`mt-4 w-full rounded-md font-semibold ${
            status === "Accepted"
              ? "bg-[rgb(87,255,47)] hover:bg-[rgb(59,128,42)]"
              : status === "Rejected"
              ? "bg-[rgb(126,41,41)]"
              : status === "Waiting"
              ? "bg-[rgb(109,112,108)]"
              : status === "WaitingNextPayment"
              ? "bg-gray-400"
              : "bg-green-400"
          } px-4 py-2 text-sm font-medium text-black transition-colors ${
            status !== "Accepted" ? "opacity-50 cursor-not-allowed" : ""
          }
          ${
            course.listOfLec.length == 0
              ? "cursor-not-allowed bg-[rgb(59,128,42)]"
              : " "
          }`}
          disabled={status !== "Accepted" || course.listOfLec.length == 0}
        >
          {suspend
            ? "ألكورس معلق"
            : status === "Accepted"
            ? "مشاهدة الكورس"
            : status === "Rejected"
            ? "تم الرفض"
            : status === "Waiting"
            ? "برجاء الانتظار"
            : status === "WaitingNextPayment"
              ? "برجاء تجديد الاشتراك"
            : null}
        </button>
      </div>
    </div>
  );
};

export default MyCourseCard;
