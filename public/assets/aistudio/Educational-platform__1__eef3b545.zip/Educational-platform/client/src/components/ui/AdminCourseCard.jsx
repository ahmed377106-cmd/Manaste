/* eslint-disable react/prop-types */
import { motion } from "framer-motion";

const AdminCourseCard = ({
  course,
  onEdit,
  onDelete,
  onViewLectures,
  userRole,
}) => {  
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      dir="rtl"
      className="group relative overflow-hidden border border-zinc-800 bg-zinc-900/50 transition-all hover:border-zinc-500 hover:-translate-y-1 rounded-lg duration-500"
    >
      <div className="p-4 text-center">
        <h3 className="mb-1 text-lg font-medium text-[rgb(87,255,47)]">
          {course.subject}
        </h3>
        <p className="mb-2 text-lg font-bold text-white">{course.teacher}</p>
        <div className="aspect-square overflow-hidden">
          <img
            src={course.teacherImg}
            alt={`${course.teacher}'s image`}
            className="object-cover w-full h-full"
          />
        </div>
        <p className="mt-3">عدد المحاضرات {course.listOfLec.length}</p>
        {userRole === "Admin" ? (
          <div className="flex gap-2 mt-4">
            <button
              onClick={onEdit}
              className="bg-[rgb(87,255,47)] font-semibold text-black px-2 py-1 rounded w-full"
            >
              تحرير
            </button>
            <button
              onClick={onViewLectures}
              className="bg-green-950 font-semibold text-white px-2 py-1 rounded w-full"
            >
              المحاضرات
            </button>
            <button
              onClick={onDelete}
              className="bg-red-900 font-semibold text-white px-2 py-1 rounded w-full"
            >
              حذف
            </button>
          </div>
        ) : null}
      </div>
    </motion.div>
  );
};

export default AdminCourseCard;
