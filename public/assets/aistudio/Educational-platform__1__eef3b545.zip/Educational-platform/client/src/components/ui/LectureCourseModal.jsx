import { useState } from 'react';
import PropTypes from 'prop-types';
import styles from "./style.module.scss"; 

const LectureCourseModal = ({ open, onClose, course, onAddLecture }) => {
  const [newLectureLink, setNewLectureLink] = useState('');

  if (!open) return null;

  const handleAddLectureClick = () => {
    onAddLecture(course._id, newLectureLink); // Call the function passed from AdminCourses
    setNewLectureLink(''); // Clear input field
    onClose(); // Close the modal
  };

  return (
    <div className={styles.modalOverlay} style={{ background: "#020202e8" }}>
      <div className={styles.modal}>
        <h2 className={styles.modalTitle}>محاضرات {course.subject}</h2>
        <ul className={"mb-5"} dir='ltr'>
          {course.listOfLec.map((lec, index) => (
            <li key={index}>
              {index + 1} - {lec}
            </li>
          ))}
        </ul>
        
        <div className={styles.addLectureContainer}>
          <input
            type="text"
            value={newLectureLink}
            onChange={(e) => setNewLectureLink(e.target.value)}
            placeholder="اضف محاضره"
            className={styles.input}
          />
          <button onClick={handleAddLectureClick} className={styles.saveButton}>
            اضف
          </button>
        </div>

        <div className={styles.modalActions}>
          <button onClick={onClose} className={styles.closeButton}>
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};

LectureCourseModal.propTypes = {
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  course: PropTypes.object.isRequired,
  onAddLecture: PropTypes.func.isRequired, // Added prop type for the new function
};

export default LectureCourseModal;
