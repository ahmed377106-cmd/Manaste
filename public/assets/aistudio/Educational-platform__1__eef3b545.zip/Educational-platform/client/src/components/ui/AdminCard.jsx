/* eslint-disable react/prop-types */
import { host } from "../../api";

const AdminCard = ({ admin, fetchAdmins, user }) => {
  const deleteAdmin = async () => {
    try {
      const response = await fetch(
        `${host}/api/auth/deleteAccount/${admin._id}`,
        {
          method: "DELETE",
        }
      );
      if (response.ok) {
        fetchAdmins();
      } else {
        console.error("Failed to delete admin:", response);
      }
    } catch (error) {
      console.error("Error deleting admin:", error);
    }
  };

  return (
    <div className="p-5 border border-gray-300 rounded-lg shadow-lg bg-zinc-950">
      <h3 className="text-xl text-[rgb(87,255,47)] font-semibold mb-2">
        {admin.name}
      </h3>
      <p className="text-sm text-gray-300">البريد الإلكتروني: {admin.email}</p>
      <p className="text-sm text-gray-300">
        الدور: {admin.role === "Admin" ? "مدير" : "أدارى"}
      </p>
      <p className="text-sm text-gray-300">رقم الهاتف: {admin.phone}</p>

      {user.role === "Admin" && (
        <div className="mt-4 flex justify-between">
          {admin.role === "Manager" && (
            <button
              onClick={deleteAdmin}
              className="bg-red-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-red-600"
            >
              حذف
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default AdminCard;
