/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { useState } from "react";
import Cookies from "js-cookie";
import { host } from "../../api.js";
import { ToastContainer, toast } from "react-toastify"; // Import Toast components
import "react-toastify/dist/ReactToastify.css"; // Import toast styles

const CourseDetailsModal = ({ course, onClose, userId }) => {
  const cashPhone = "011111111";
  const whatsPhone = "01111111";
  const price = "100";
  const [courseExists, setCourseExists] = useState(false);
  const [load, setLoad] = useState(false);
  const [done, setDone] = useState(false);
  const [subscrib, setSubscrib] = useState(false);

  const handleSubscribe = async () => {
    const token = Cookies.get("token");
    setLoad(true);
    try {
      const response = await fetch(`${host}/api/cart`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          userId: userId,
          courseId: course._id,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        console.log("Course added to cart:", data);
        onClose();
      } else if (response.status === 301) {
        setSubscrib(true);
      }
      setDone(true);
    } catch (error) {
      console.error("Error occurred while subscribing:", error);
    } finally {
      setLoad(false);
    }
    setTimeout(() => {
      setDone(false);
      setSubscrib(false);
      onClose();
    }, 2000);
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center  bg-black bg-opacity-70 z-50 p-10 transition-opacity duration-300 ease-in-out"
    >
      <div className="bg-black rounded-lg border-2 border-white/30 flex flex-col w-11/12 md:w-2/3 lg:w-1/2 animate-fade-in">
        <button
          onClick={onClose}
          className="text-red-500 text-right mr-3 text-3xl mt font-bold float-right"
        >
          ×
        </button>
        <h3 className="text-white mr-3 text-xl">
          للاشتراك في كورس{" "}
          <span className="text-[rgb(87,255,47)]">{course.subject}</span> عليك
          ارسال مبلغ <span className="text-[rgb(87,255,47)]">{price}</span> فى
          محفظه هذا الرقم{" "}
          <div className="text-[rgb(87,255,47)]">{cashPhone}</div> و يجب عليك
          ارسال صورة من عمليه الدفع على هذا الرقم{" "}
          <div className="text-[rgb(87,255,47)]">{whatsPhone}</div>. و يجب ارسال
          اسمك بالمنصه و ايضا بريدك الالكتروني و اسم المادة و اسم مدرس المادة
        </h3>

        <button
          onClick={handleSubscribe}
          className="m-4 rounded-md bg-[rgb(87,255,47)] hover:bg-[rgb(67,235,27)] px-4 py-2 text-xl font-semibold text-black transition-colors"
        >
          {subscrib
            ? "انت مشترك بالفعل"
            : done
            ? "تم الاشتراك بنجاح"
            : !load
            ? "أشتراك"
            : "جارى تقديم الطلب"}
        </button>
      </div>
      <ToastContainer />{" "}
      {/* Add ToastContainer to render the toast notifications */}
    </div>
  );
};

export default CourseDetailsModal;
