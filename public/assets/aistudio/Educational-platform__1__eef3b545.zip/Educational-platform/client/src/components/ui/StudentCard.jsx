/* eslint-disable react/prop-types */
// StudentCard Component
import { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { host } from "../../api";

const StudentCard = ({ student, courses, cartId, fetchStudents }) => {
  const [selectedStatus, setSelectedStatus] = useState({});

  useEffect(() => {
    const initialStatus = courses.reduce((acc, course) => {
      acc[course.course._id] = course.status;
      return acc;
    }, {});
    setSelectedStatus(initialStatus);
  }, [courses]);

  const translateStatus = (status) => {
    switch (status) {
      case "Accepted":
        return "مقبول";
      case "Rejected":
        return "مرفوض";
      case "Waiting":
        return "انتظار القبول";
      case "WaitingNextPayment":
        return "انتظار الدفع التالي";
      default:
        return status;
    }
  };

  // Determine the text color based on the course status
  const getStatusColor = (status) => {
    switch (status) {
      case "Accepted":
        return "text-green-500";
      case "Rejected":
        return "text-red-500";
      case "Waiting":
        return "text-yellow-500";
      case "WaitingNextPayment":
        return "text-blue-500";
      default:
        return "text-gray-500";
    }
  };

  const handleStatusChange = (courseId, newStatus) => {
    setSelectedStatus((prev) => ({
      ...prev,
      [courseId]: newStatus,
    }));
  };

  const handleSaveStatus = async (courseId) => {
    const token = Cookies.get("token");
    const newStatus = selectedStatus[courseId];

    try {
      await axios.patch(
        `${host}/api/cart/update-status`,
        {
          cartId,
          courseId: courseId,
          status: newStatus,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      fetchStudents();
    } catch (error) {
      console.error("Error updating status:", error.message);
      alert("فشل تحديث الحالة");
    }
  };

  return (
    <div className="border-2 border-white/30 bg-zinc-950 p-4 rounded-lg shadow-lg transition-transform transform hover:scale-[1.02] duration-500 overflow-hidden">
      <h3 className="text-xl font-bold mb-2 ">{student.name}</h3>
      <p className="text-gray-400 mb-2 w-full">{student.email}</p>
      <p className="text-gray-400 mb-2">
        {student.year === "First"
          ? "الصف الاول"
          : student.year === "Second"
          ? "الصف الثاني"
          : student.year === "Third"
          ? "الصف الثالث"
          : student.year}
      </p>
      <p className="text-gray-400 mb-2">{student.phone}</p>
      <p className="text-red-400 mb-2">{student.fatherPhone}</p>

      <h4 className="text-lg text-[rgb(87,255,47)] font-semibold mb-2">
        الكورسات
      </h4>
      <ul className="space-y-2">
        {courses.map((course, idx) => (
          <li
            key={idx}
            className="text-sm flex justify-between items-center border-b-2 border-white/10 text-center pb-2"
          >
            <div className="flex flex-col">
              <strong>{course.course.subject}</strong>{" "}
              <strong>{course.course.teacher}</strong>
              <span className={`text-sm ${getStatusColor(course.status)}`}>
                {translateStatus(course.status)}
              </span>
            </div>

            <div className="flex items-center flex-col space-y-2 sm:flex-row sm:space-y-0">
              <select
                value={selectedStatus[course.course._id] || course.status}
                onChange={(e) =>
                  handleStatusChange(course.course._id, e.target.value)
                }
                className="p-1 w-fit sm:w-w-50 border rounded mr-2 focus:border-[rgb(87,255,47)]"
              >
                <option value="Accepted">مقبول</option>
                <option value="Rejected">مرفوض</option>
                <option value="Waiting">انتظار القبول</option>
                <option value="WaitingNextPayment">انتظار الدفع التالي</option>
              </select>

              <button
                onClick={() => handleSaveStatus(course.course._id)}
                className="text-black w-full font-semibold bg-[rgb(87,255,47)] px-3 py-1 rounded mr-2"
              >
                حفظ
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudentCard;
