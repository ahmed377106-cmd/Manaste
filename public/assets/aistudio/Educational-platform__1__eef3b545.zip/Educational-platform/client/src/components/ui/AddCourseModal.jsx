/* eslint-disable react/prop-types */
import { useState } from "react";
import styles from "./style.module.scss";
import { host } from "../../api";

const AddCourseModal = ({ onClose, onSave }) => {
  const [subject, setSubject] = useState("");
  const [teacher, setTeacher] = useState("");
  const [teacherImg, setTeacherImg] = useState("");
  const [year, setYear] = useState("");
  const [term, setTerm] = useState(""); 
  const [suspend, setSuspend] = useState(false);
  const [description, setDescription] = useState("");
  const [branch, setBranch] = useState("");

  // State for error messages
  const [errorMessage, setErrorMessage] = useState({
    year: false,
    term: false, 
    branch: false,
    apiError: "", 
  });

  const handleYearChange = (e) => {
    const selectedYear = e.target.value;
    setYear(selectedYear);

    // Validate year selection
    if (selectedYear === "") {
      setErrorMessage((prev) => ({ ...prev, year: true }));
    } else {
      setErrorMessage((prev) => ({ ...prev, year: false }));
      setBranch(""); 
      setTerm(""); 
    }
  };

  const handleBranchChange = (e) => {
    const selectedBranch = e.target.value;
    setBranch(selectedBranch);

    // Validate branch selection
    if (selectedBranch === "") {
      setErrorMessage((prev) => ({ ...prev, branch: true }));
    } else {
      setErrorMessage((prev) => ({ ...prev, branch: false }));
    }
  };

  const handleTermChange = (e) => {
    const selectedTerm = e.target.value;
    setTerm(selectedTerm);

    // Validate term selection
    if (selectedTerm === "") {
      setErrorMessage((prev) => ({ ...prev, term: true }));
    } else {
      setErrorMessage((prev) => ({ ...prev, term: false }));
    }
  };

  const handleSave = async () => {
    if (year === "") {
      setErrorMessage((prev) => ({ ...prev, year: true }));
      return;
    }
    if (term === "") { 
      setErrorMessage((prev) => ({ ...prev, term: true }));
      return;
    }
    if (branch === "") {
      setErrorMessage((prev) => ({ ...prev, branch: true }));
      return;
    }

    const newCourse = {
      subject,
      teacher,
      teacherImg,
      year,
      term,
      suspend,
      description,
      branch,
    };

    try {
      const response = await fetch(`${host}/api/courses`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newCourse),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        setErrorMessage((prev) => ({ ...prev, apiError: errorData.msg || "خطأ في إضافة الدورة" }));
        return;
      }

      const result = await response.json();
      onSave(result); 
      onClose(); 
    } catch (error) {
      console.error("Error adding course:", error);
      setErrorMessage((prev) => ({ ...prev, apiError: "خطأ في الاتصال بالخادم" }));
    }
  };

  return (
    <div className={styles.modalOverlay} style={{ background: "#020202e8" }}>
      <div className={styles.modal}>
        <button onClick={onClose} className={styles.closeButton}>✕</button>
        <h3 className={styles.modalTitle}>إضافة دورة جديدة</h3>

        {errorMessage.apiError && <div className="text-center text-red-600 font-semibold text-lg">{errorMessage.apiError}</div>} {/* Display API error message */}

        <label className={styles.label}>الموضوع</label>
        <input
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          className={styles.input}
          placeholder="أدخل الموضوع"
        />

        <label className={styles.label}>المدرس</label>
        <input
          type="text"
          value={teacher}
          onChange={(e) => setTeacher(e.target.value)}
          className={styles.input}
          placeholder="أدخل اسم المدرس"
        />

        <label className={styles.label}>رابط صورة المدرس</label>
        <input
          type="text"
          value={teacherImg}
          onChange={(e) => setTeacherImg(e.target.value)}
          className={styles.input}
          placeholder="أدخل رابط صورة المدرس"
        />

        {/* New Year Field with Options */}
        <label className={styles.label}>السنة</label>
        <select
          value={year}
          onChange={handleYearChange}
          className={errorMessage.year ? "error" : styles.select}
        >
          <option value="">اختر السنه الدراسيه</option>
          <option value="First">الصف الاول</option>
          <option value="Second">الصف الثاني</option>
          <option value="Third">الصف الثالث</option>
        </select>
        {errorMessage.year && <span className={styles.errorMessage}>يرجى اختيار السنة الدراسية</span>}

        <label className={styles.label}>التخصص</label>
        <select
          value={branch}
          onChange={handleBranchChange}
          className={errorMessage.branch ? "error" : styles.select}
        >
          <option value="">اختر القسم</option>
          {year === "First" ? (
            <>
              <option value="Scientific">علمي</option>
              <option value="Literary">ادبي</option>
            </>
          ) : (
            <>
              <option value="Scientific_Sciences">علمي علوم</option>
              <option value="Math_Science">علمي رياضه</option>
              <option value="Literary">ادبي</option>
            </>
          )}
        </select>
        {errorMessage.branch && <span className={styles.errorMessage}>يرجى اختيار القسم</span>}

        {/* New Term Field with Options */}
        <label className={styles.label}>الفصل الدراسي</label>
        <select
          value={term}
          onChange={handleTermChange}
          className={errorMessage.term ? "error" : styles.select}
        >
          <option value="">اختر الفصل الدراسي</option>
          <option value="First">الفصل الدراسي الاول</option>
          <option value="Second">الفصل الدراسي الثاني</option>
        </select>
        {errorMessage.term && <span className={styles.errorMessage}>يرجى اختيار الفصل الدراسي</span>}

        <label className={styles.label}>تعليق الدورة</label>
        <select
          value={suspend}
          onChange={(e) => setSuspend(e.target.value === "true")}
          className={styles.select}
        >
          <option value="false">نشطة</option>
          <option value="true">معلقة</option>
        </select>

        <label className={styles.label}>الوصف</label>
        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className={styles.input}
          placeholder="أدخل وصف الدورة"
        />

        <div className={styles.modalActions}>
          <button onClick={onClose} className={styles.cancelButton}>إلغاء</button>
          <button onClick={handleSave} className={styles.saveButton}>حفظ</button>
        </div>
      </div>
    </div>
  );
};

export default AddCourseModal;
