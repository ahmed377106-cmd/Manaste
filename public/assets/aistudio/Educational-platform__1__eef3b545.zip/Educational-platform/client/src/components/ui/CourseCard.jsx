/* eslint-disable react/prop-types */
import { motion } from "framer-motion"; // Import motion from framer-motion

const CourseCard = ({ courseItem, buttonLabel, onButtonClick, userRole }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }} // Initial state for the animation
      animate={{ opacity: 1, scale: 1 }} // Final state for the animation
      transition={{ duration: 0.3 }} // Duration of the animation
      dir="rtl"
      className="group relative overflow-hidden border border-zinc-800 bg-zinc-900/50 transition-all hover:border-zinc-500 hover:-translate-y-1 rounded-lg duration-500"
    >
      <div className="p-4 text-center">
        <h3 className="mb-1 text-lg font-medium text-[rgb(87,255,47)]">
          {courseItem.subject}
        </h3>
        <p className="mb-2 text-lg font-bold text-white">
          {courseItem.teacher}
        </p>
        <p className="mb-1 text-md text-zinc-400">
          {courseItem.year === "First" ? "الصف الاول الثانوى" : ""}
          {courseItem.year === "Second" ? "الصف الثانى الثانوى" : ""}
          {courseItem.year === "Third" ? "الصف الثالث الثانوى" : ""}
        </p>
        <p className="mb-2 text-sm text-zinc-400">
          {courseItem.term === "First" ? "الفصل الدراسى الاول" : ""}
          {courseItem.term === "Second" ? "الفصل الدراسى الثانى" : ""}
        </p>

        <div className="aspect-square overflow-hidden">
          <img
            src={courseItem.teacherImg}
            alt={`${courseItem.teacher}'s image`}
            className="object-cover w-full h-full"
          />
        </div>
        <p className="mt-4 text-zinc-400">
          عدد المحاضرات : {courseItem.listOfLec.length}
        </p>

        <button
          onClick={onButtonClick}
          className={`mt-4 w-full rounded-md bg-[rgb(87,255,47)] hover:bg-[rgb(67,235,27)] px-4 py-2 text-lg font-medium text-black transition-colors ${
            userRole === "Admin" || userRole === "Manager"
              ? "opacity-50 cursor-not-allowed"
              : ""
          }`}
          disabled={userRole === "Admin" || userRole === "Manager"}
        >
          {buttonLabel || "أحجز الان"}
        </button>
      </div>
    </motion.div>
  );
};

export default CourseCard;
