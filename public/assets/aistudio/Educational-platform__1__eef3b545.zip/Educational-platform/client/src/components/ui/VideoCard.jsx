/* eslint-disable react/prop-types */

const VideoCard = ({ episodeLink }) => {
  // Function to extract the video ID from a Google Drive link
  const getDriveFileId = (url) => {
    const urlObj = new URL(url);
    const idMatch = urlObj.pathname.match(/\/d\/(.+?)(\/|$)/);
    return idMatch ? idMatch[1] : null; // Returns the file ID if it matches
  };

  // Extract video ID or file ID based on the type of link
  const videoId = episodeLink.includes("youtube.com")
    ? episodeLink.split("v=")[1]
    : null;
  const driveFileId = episodeLink.includes("drive.google.com")
    ? getDriveFileId(episodeLink)
    : null;
  const isMediaDeliveryLink = episodeLink.includes("iframe.mediadelivery.net");
  

  return (
    <div className="aspect-video w-full bg-gray-800 rounded-lg overflow-hidden">
      {videoId ? (
        <iframe
          width="100%"
          height="100%"
          src={`https://www.youtube.com/embed/${videoId}`}
          title="YouTube video player"
          frameBorder="0"
          allow="autoplay; clipboard-write; encrypted-media; gyroscope"
          allowFullScreen
        ></iframe>
      ) : driveFileId ? (
        <iframe
          width="100%"
          height="100%"
          src={`https://drive.google.com/file/d/${driveFileId}/preview`}
          title="Google Drive video player"
          frameBorder="0"
          allow="autoplay; encrypted-media"
          allowFullScreen
        ></iframe>
      ) : isMediaDeliveryLink ? (
        <iframe
          width="100%"
          height="100%"
          src={episodeLink}
          title="Media Delivery video player"
          frameBorder="0"
          allow="autoplay; encrypted-media"
          allowFullScreen
        ></iframe>
      ) : (
        <div className="w-full h-full flex items-center justify-center text-gray-400">
          Invalid Video Link
        </div>
      )}
    </div>
  );
};

export default VideoCard;
