/* eslint-disable react/prop-types */
import { useState } from "react";
import styles from "./style.module.scss";
import { host } from "../../api";

const AddManagerModal = ({ onClose, onSave }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [errorMessage, setErrorMessage] = useState({
    name: false,
    email: false,
    password: false,
    phone: false,
  });
  const [serverErrorMessage, setServerErrorMessage] = useState(""); // State for server error message

  const handleSave = async () => {
    if (!name || !email || !password || !phone) {
      setErrorMessage({
        name: !name,
        email: !email,
        password: !password,
        phone: !phone,
      });
      setServerErrorMessage("يجب ملء جميع الحقول المطلوبة"); 
      return;
    }

    const newManager = {
      name,
      email,
      password,
      phone,
      role: "Manager",
    };

    try {
      const response = await fetch(`${host}/api/auth/addadmin`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newManager),
      });

      if (!response.ok) {
        const errorData = await response.json();
        setServerErrorMessage(errorData.msg || "فشل في إضافة المدير"); 
        return;
      }

      const result = await response.json();
      onSave(result);  // Call onSave to update the parent component
      onClose(); // Close modal
    } catch (error) {
      setServerErrorMessage("حدث خطأ أثناء إضافة المدير. حاول مرة أخرى.");
      console.error("Error adding manager:", error);
    }
  };

  return (
    <div className={`${styles.modalOverlay} bg-black/80`} dir="rtl">
      <div className={styles.modal}>
        <button onClick={onClose} className={styles.closeButton}>
          ✕
        </button>

        <h3 className={styles.modalTitle}>إضافة مدير جديد</h3>

        {/* Display server error message at the top */}
        {serverErrorMessage && (
          <div className={"text-center text-red-700"}>{serverErrorMessage}</div>
        )}

        <label className={styles.label}>الاسم</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className={`${styles.input} ${errorMessage.name ? styles.error : ""}`}
          placeholder="أدخل الاسم"
        />
        {errorMessage.name && (
          <span className={styles.errorMessage}>الاسم مطلوب</span>
        )}

        <label className={styles.label}>البريد الإلكتروني</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className={`${styles.input} ${errorMessage.email ? styles.error : ""}`}
          placeholder="أدخل البريد الإلكتروني"
        />
        {errorMessage.email && (
          <span className={styles.errorMessage}>البريد الإلكتروني مطلوب</span>
        )}

        <label className={styles.label}>كلمة المرور</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className={`${styles.input} ${errorMessage.password ? styles.error : ""}`}
          placeholder="أدخل كلمة المرور"
        />
        {errorMessage.password && (
          <span className={styles.errorMessage}>كلمة المرور مطلوبة</span>
        )}

        <label className={styles.label}>رقم الهاتف</label>
        <input
          type="rtl"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className={`${styles.input} ${errorMessage.phone ? styles.error : ""}`}
          placeholder="أدخل رقم الهاتف"
        />
        {errorMessage.phone && (
          <span className={styles.errorMessage}>رقم الهاتف مطلوب</span>
        )}

        <label className={styles.label}>الدور</label>
        <select value="Admin" className={`${styles.select} cursor-not-allowed`} disabled>
          <option value="Admin">أدارى</option>
        </select>

        <div className={styles.modalActions}>
          <button onClick={onClose} className={styles.cancelButton}>
            إلغاء
          </button>
          <button onClick={handleSave} className={styles.saveButton}>
            حفظ
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddManagerModal;
