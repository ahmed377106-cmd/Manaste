"use client";
import { Link } from 'react-router-dom';
import styles from './footer.module.scss';
import { useRef, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookF, faLinkedin, faWhatsapp, faXTwitter } from '@fortawesome/free-brands-svg-icons';

export default function Footer() {
  const path = useRef(null);
  let progress = 0;
  let x = 0.5;
  let time = Math.PI / 2;
  let reqId = null;

  useEffect(() => {
    setPath(progress);
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleResize = () => {
    setPath(progress);
  };

  const setPath = (progress) => {
    const width = window.innerWidth * 0.9;
    path.current.setAttributeNS(null, "d", `M0 250 Q${width * x} ${250 + progress}, ${width} 250`);
  };

  const lerp = (x, y, a) => x * (1 - a) + y * a;

  const manageMouseEnter = () => {
    if (reqId) {
      cancelAnimationFrame(reqId);
      resetAnimation();
    }
  };

  const manageMouseMove = (e) => {
    const { movementY, clientX } = e;
    const pathBound = path.current.getBoundingClientRect();
    x = (clientX - pathBound.left) / pathBound.width;
    progress += movementY;
    setPath(progress);
  };

  const manageMouseLeave = () => {
    animateOut();
  };

  const animateOut = () => {
    const newProgress = progress * Math.sin(time);
    progress = lerp(progress, 0, 0.025);
    time += 0.2;
    setPath(newProgress);
    if (Math.abs(progress) > 0.75) {
      reqId = requestAnimationFrame(animateOut);
    } else {
      resetAnimation();
    }
  };

  const resetAnimation = () => {
    time = Math.PI / 2;
    progress = 0;
  };

  return (
    <div className={styles.container}>
      <div className={styles.body}>
        <div className={styles.line}>
          <div
            onMouseEnter={manageMouseEnter}
            onMouseMove={manageMouseMove}
            onMouseLeave={manageMouseLeave}
            className={styles.box}
          ></div>
          <svg>
            <path ref={path}></path>
          </svg>
        </div>
        <div className={styles.content}>
          <div className={styles.top}>
            <div className={styles.aboutMeBox}>
              <p>عني</p>
              <h3>
                أنا شخص يتمتع بشغف كبير بمساعدة الآخرين على تحقيق أهدافهم التعليمية وتطوير مهاراتهم.
                بفضل خبرتي وشهاداتي المعتمدة في تدريس قدرات التأسيس واللغة الإنجليزية، أسعى دائمًا إلى
                توجيه الطلاب نحو النجاح وتعزيز ثقتهم في قدراتهم. أؤمن بأهمية بناء علاقات تعليمية قوية مع
                الطلاب، وتكييف الدروس لتلبية احتياجاتهم الفردية. باعتباري مدرسًا ملتزمًا بالتميز
                والتطوير المستمر، فإنني أسعى جاهدًا لتقديم بيئة تعليمية داعمة ومحفزة تسهم في تحقيق نتائج
                إيجابية ومستدامة للطلاب.
              </h3>
            </div>
            <div className={styles.linksBox}>
              <p>الصفحات</p>
              <div>
                <Link to="/">الرئيسية</Link>
                <Link to="/courses">الدورات</Link>
                <Link to="/about">عني</Link>
                <Link to="/contact">تواصل معي</Link>
                <Link to="/blog">خطوات التسجيل</Link>
                <Link to="/privacy">سياسة الخصوصية</Link>
                <Link to="/terms">الشروط والأحكام</Link>
              </div>
            </div>
            <div className={styles.socialsBox}>
              <p>التواصل الاجتماعي</p>
              <div>
                <Link to="/" title="Facebook"><FontAwesomeIcon icon={faFacebookF} /></Link>
                <Link to="/" title="Whatsapp"><FontAwesomeIcon icon={faWhatsapp} /></Link>
                <Link to="/" title="Twitter"><FontAwesomeIcon icon={faXTwitter} /></Link>
                <Link to="/" title="Linkedin"><FontAwesomeIcon icon={faLinkedin} /></Link>
              </div>
            </div>
          </div>
          <div className={styles.bottom}>
            <p>جميع الحقوق محفوظة لدى vertas © 2024</p>
            <div>
              <Link to="/privacy">سياسة الخصوصية</Link>
              <span>•</span>
              <Link to="/terms">الشروط والأحكام</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
