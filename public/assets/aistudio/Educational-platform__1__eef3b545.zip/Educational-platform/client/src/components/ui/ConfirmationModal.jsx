/* eslint-disable react/prop-types */

const ConfirmationModal = ({ isOpen, onClose, onConfirm, courseName, teacherName }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#000000c2] z-50 p-10 transition-opacity duration-300 ease-in-out">
      <div className="bg-[#000000] rounded-lg border-2 border-white/30  flex flex-col w-11/12 md:w-2/3 lg:w-1/2 xl:w-2/6 animate-fade-in">
        <button
          onClick={onClose}
          className="text-red-500 text-right mr-3 text-3xl font-bold float-right"
        >
          ×
        </button>
        <h2 className="text-white mr-3 text-xl font-semibold">تأكيد الحذف</h2>
        <p className="text-white mr-3 mb-4">
          هل أنت متأكد أنك تريد حذف الدورة: <strong className="text-[rgb(87,255,47)]">{courseName}</strong> التي يدرسها <strong className="text-[rgb(87,255,47)]">{teacherName}</strong>؟
        </p>
        <div className="flex justify-end mb-4 space-x-2 gap-2">
          <button onClick={onClose} className="font-semibold mr-2 w-full px-4 py-2 bg-[rgb(87,255,47)] rounded-md text-black hover:bg-[rgba(89,255,47,0.88)]">إلغاء</button>
          <button onClick={onConfirm} className="font-semibold px-4 w-full py-2 bg-red-600 hover:bg-red-700 text-white rounded-md">حذف</button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;
