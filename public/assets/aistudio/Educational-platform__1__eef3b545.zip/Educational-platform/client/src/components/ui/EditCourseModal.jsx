/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { useState } from "react";
import styles from "./style.module.scss";
import { host } from "../../api";

const EditCourseModal = ({ course, onClose, onSave }) => {
  const [subject, setSubject] = useState(course.subject || "");
  const [teacher, setTeacher] = useState(course.teacher || "");
  const [teacherImg, setTeacherImg] = useState(course.teacherImg || "");
  const [year, setYear] = useState(course.year || "");
  const [term, setTerm] = useState(course.term || "");
  const [suspend, setSuspend] = useState(course.suspend || false);
  const [description, setDescription] = useState(course.description || "");
  const [branch, setBranch] = useState(course.branch || "");
  
  // State for error messages
  const [errorMessage, setErrorMessage] = useState({
    year: false,
    branch: false,
  });

  const handleYearChange = (e) => {
    const selectedYear = e.target.value;
    setYear(selectedYear);

    // Validate year selection
    if (selectedYear === "") {
      setErrorMessage((prev) => ({ ...prev, year: true }));
    } else {
      setErrorMessage((prev) => ({ ...prev, year: false }));
      setBranch(""); // Reset branch selection when year changes
    }
  };

  const handleBranchChange = (e) => {
    const selectedBranch = e.target.value;
    setBranch(selectedBranch);

    // Validate branch selection
    if (selectedBranch === "") {
      setErrorMessage((prev) => ({ ...prev, branch: true }));
    } else {
      setErrorMessage((prev) => ({ ...prev, branch: false }));
    }
  };

  const handleSave = async () => {
    // Check for validation before saving
    if (year === "") {
      setErrorMessage((prev) => ({ ...prev, year: true }));
      return;
    }
    if (branch === "") {
      setErrorMessage((prev) => ({ ...prev, branch: true }));
      return;
    }
  
    const updatedCourse = {
      ...course,
      subject,
      teacher,
      teacherImg,
      year,
      term,
      suspend,
      description,
      branch,
    };
  
    try {
      const response = await fetch(`${host}/api/courses/${course._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedCourse),
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.msg || "خطأ في تحديث الدورة");
      }
  
      const result = await response.json();
      onSave(result); // Pass the updated course data back to the parent component
      onClose(); // Close the modal
    } catch (error) {
      console.error("Error updating course:", error);
      // Optionally, you can show an error message to the user
    }
  };
  

  return (
    <div className={styles.modalOverlay} style={{background: "#020202e8"}}>
      <div className={styles.modal}>
        <button onClick={onClose} className={styles.closeButton}>✕</button>
        <h3 className={styles.modalTitle}>تحرير الدورة</h3>

        <label className={styles.label}>الموضوع</label>
        <input
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          className={styles.input}
          placeholder="أدخل الموضوع"
        />

        <label className={styles.label}>المدرس</label>
        <input
          type="text"
          value={teacher}
          onChange={(e) => setTeacher(e.target.value)}
          className={styles.input}
          placeholder="أدخل اسم المدرس"
        />

        <label className={styles.label}>رابط صورة المدرس</label>
        <input
          type="text"
          value={teacherImg}
          onChange={(e) => setTeacherImg(e.target.value)}
          className={styles.input}
          placeholder="أدخل رابط صورة المدرس"
        />

        {/* New Year Field with Options */}
        <label className={styles.label}>السنة</label>
        <select
          value={year}
          onChange={handleYearChange}
          className={errorMessage.year ? "error" : styles.select}
        >
          <option value="">اختر السنه الدراسيه</option>
          <option value="First">الصف الاول</option>
          <option value="Second">الصف الثاني</option>
          <option value="Third">الصف الثالث</option>
        </select>
        {errorMessage.year && <span className={styles.errorMessage}>يرجى اختيار السنة الدراسية</span>}

        <label className={styles.label}>التخصص</label>
        <select
          value={branch}
          onChange={handleBranchChange}
          className={errorMessage.branch ? "error" : styles.select}
        >
          <option value="">اختر القسم</option>
          {year === "First" ? (
            <>
              <option value="Scientific">علمي</option>
              <option value="Literary">ادبي</option>
            </>
          ) : (
            <>
              <option value="Scientific_Sciences">علمي علوم</option>
              <option value="Math_Science">علمي رياضه</option>
              <option value="Literary">ادبي</option>
            </>
          )}
        </select>
        {errorMessage.branch && <span className={styles.errorMessage}>يرجى اختيار القسم</span>}

        <label className={styles.label}>تعليق الدورة</label>
        <select
          value={suspend}
          onChange={(e) => setSuspend(e.target.value === "true")}
          className={styles.select}
        >
          <option value="false">نشطة</option>
          <option value="true">معلقة</option>
        </select>

        <label className={styles.label}>الوصف</label>
        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className={styles.input}
          placeholder="أدخل وصف الدورة"
        />

        <div className={styles.modalActions}>
          <button onClick={onClose} className={styles.cancelButton}>إلغاء</button>
          <button onClick={handleSave} className={styles.saveButton}>حفظ</button>
        </div>
      </div>
    </div>
  );
};

export default EditCourseModal;
