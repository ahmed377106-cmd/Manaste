/* eslint-disable react/prop-types */
import { motion } from "framer-motion";

const OrderCard = ({ courseItem, user, onAccept, onReject }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }} 
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      dir="rtl"
      className="group relative overflow-hidden border border-zinc-800 bg-zinc-900/50 transition-all hover:border-zinc-500 hover:-translate-y-1 rounded-lg duration-500"
    >
      <div className="p-4 text-center" dir="rtl">
        <h3 className="mb-1 text-lg font-medium text-[rgb(87,255,47)]">
          {courseItem.subject}
        </h3>
        <p className="mb-2 text-lg font-bold text-white">
          {courseItem.teacher}
        </p>
        <p className="mb-1 text-md text-zinc-400">
          {courseItem.year === "First" ? "الصف الاول الثانوى" : ""}
          {courseItem.year === "Second" ? "الصف الثانى الثانوى" : ""}
          {courseItem.year === "Third" ? "الصف الثالث الثانوى" : ""}
        </p>
        <p className="mb-2 text-sm text-zinc-400">
          {courseItem.term === "First" ? "الفصل الدراسى الاول" : ""}
          {courseItem.term === "Second" ? "الفصل الدراسى الثانى" : ""}
        </p>

        <div className="aspect-square overflow-hidden mb-4">
          <img
            src={courseItem.teacherImg}
            alt={`${courseItem.teacher}'s image`}
            className="object-cover w-full h-full rounded-md" 
          />
        </div>
        
        <div className="mt-4 text-whit text-right" dir="rtl">
          <h4 className="font-bold text-center text-[rgb(87,255,47)]">معلومات الطالب</h4>
          <p>الاسم: {user.name}</p>
          <p>البريد الإلكتروني: <br/> {user.email}</p>
          <p>رقم الهاتف: {user.phone}</p>
        </div>

        <div className="mt-4 flex justify-between">
          <button 
            onClick={onAccept}
            className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition"
          >
            تاكيد
          </button>
          <button 
            onClick={onReject}
            className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition"
          >
            رفض
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default OrderCard;
