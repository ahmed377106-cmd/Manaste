import { useEffect, useState } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Layout from "./layout/Layout.jsx";
import Home from "./page";
import SignUp from "./pagesComponents/SignUp/SignUp";
import Login from "./pagesComponents/Login/Login";
import Cookies from "js-cookie";
import axios from "axios";
import StudentCourses from "./pagesComponents/StudentCourses/StudentCourses";
import FullPageLoading from "./components/ui/FullPageLoading.js";
import Courses from "./pagesComponents/courses/Courses"
import AdminCourses from "./pagesComponents/adminCourses/AdminCourses"
import Orders from "./pagesComponents/orders/Orders"
import WatchCourse from "./pagesComponents/watchCourse/WatchCourse.jsx";
import Students from "./pagesComponents/students/Students";
import Managers from "./pagesComponents/managers/Managers";
import { host } from "./api";
import ErrorPage from "./pagesComponents/errorPage/ErrorPage";
import "./globals.css";

function App() {
  const [user, setUser] = useState(null); // State to store user information
  const [tokenExpired, setTokenExpired] = useState(false); 
  const [loading, setLoading] = useState(true); // Loading state for spinner
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const token = Cookies.get("token");
      if (!token) {
        setTokenExpired(false);
        setLoading(false); // Stop loading if there's no token
        return;
      }

      try {
        const response = await axios.get(`${host}/api/auth/profile`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setUser(response.data);
        setTokenExpired(true);
      } catch (error) {
        console.error("Authorization failed:", error);
        setTokenExpired(false);
      } finally {
        setLoading(false); 
      }
    };

    checkAuth();
  }, [navigate]);

  if (loading) {
    return <FullPageLoading loading={loading} />;
  }
  
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home user={user} tokenState={tokenExpired} />} /> 
        <Route path="login" element={<Login />} />
        <Route path="signup" element={<SignUp />} />
        <Route path="courses/:id" element={<StudentCourses user={user} tokenState={tokenExpired} />} />
        <Route path="courses" element={<Courses user={user} tokenState={tokenExpired} />} />
        {tokenExpired && <Route path="watch/:id" element={<WatchCourse user={user} tokenState={tokenExpired} />} />}
        
        {user && ( user.role === "Admin" || user.role === "Manager") ? (
          <>
          <Route path="students" element={<Students user={user} tokenState={tokenExpired} />} />
          <Route path="coursesdashboard" element={<AdminCourses user={user} tokenState={tokenExpired} />} />
          <Route path="orders" element={<Orders user={user} tokenState={tokenExpired} />} />
          <Route path="managers" element={<Managers user={user} tokenState={tokenExpired} />} />
          </>
        ) :(null)}
        <Route path="*" element={<ErrorPage />} />
      </Route>
    </Routes>
  );
}

export default App;
