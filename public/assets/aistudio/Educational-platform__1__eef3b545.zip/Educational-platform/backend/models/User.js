const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
      minlength: [8, "Password must be at least 8 characters long"]
    },
    role: {
      type: String,
      enum: ["Admin", "Manager", "Student"],
      default: "Student",
    },
    blocked: {
      type: Boolean,
      default: false,
    },
    year: {
      type: String,
      enum: ["First", "Second", "Third"],
    },
    branch: {
      type: String,
      enum: ["Scientific", "Literary", "Math_Science", "Scientific_Sciences"],
    },
    phone: {
      type: String,
      required: true,
      minlength: [11, "Phone number must be exactly 11 characters long"],
      maxlength: [11, "Phone number must be exactly 11 characters long"],
    },
    fatherPhone: {
      type: String,
      minlength: [11, "Phone number must be exactly 11 characters long"],
      maxlength: [11, "Phone number must be exactly 11 characters long"],
    },
  },
  {
    timestamps: true,
  }
);

// Hash password before saving to the database
userSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
  }
  next();
});

// Method to compare passwords
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

const User = mongoose.model("User", userSchema);
module.exports = User;
