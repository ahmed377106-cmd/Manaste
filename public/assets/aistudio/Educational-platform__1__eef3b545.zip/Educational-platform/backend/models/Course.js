const mongoose = require("mongoose");

const CourseSchema = new mongoose.Schema(
  {
    subject: { type: String, required: true },
    year: { type: String, required: true, enum: ["First", "Second", "Third"] },
    term: { type: String, required: true, enum: ["First", "Second"] },
    teacher: { type: String, required: true },
    teacherImg: { type: String },
    listOfLec: [{ type: String }],
    suspend: { type: Boolean, default: false },
    description: { type: String },
    branch: {
      type: String,
      required: true,
      enum: ["Scientific", "Literary", "Math_Science", "Scientific_Sciences"],
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Course", CourseSchema);
