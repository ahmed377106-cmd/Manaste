const Course = require("../models/Course");

// Get all courses
exports.getAllCourses = async (req, res) => {
  try {
    const courses = await Course.find();
    res.status(200).json(courses);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ msg: "Server error" });
  }
};

// Get a course by ID
exports.getCourseById = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ msg: "هذا الكورس غير متاح" });
    }
    res.status(200).json(course);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ msg: "Server error" });
  }
};

// Add a new course
exports.addCourse = async (req, res) => {
  const {
    subject,
    year,
    term,
    teacher,
    teacherImg,
    listOfLec,
    description,
    branch,
  } = req.body;

  if (!subject || !year || !term || !teacher || !description || !branch) {
    return res.status(400).json({ msg: "جميع الحقول مطلوبة" });
  }

  // Validate subject
  if (subject.length < 2) {
    return res.status(400).json({ msg: "يجب ان لا يقل الاسم عن 3 حروف" });
  }

  // Validate year
  const validYears = ["First", "Second", "Third"];
  if (!validYears.includes(year)) {
    return res.status(400).json({ msg: "يجب ادخال السنه الدراسية" });
  }

  // Validate term
  const validTerms = ["First", "Second"];
  if (!validTerms.includes(term)) {
    return res.status(400).json({ msg: "يجب ادخال الفصل الدراسى" });
  }

  // Validate teacher name
  if (teacher.length < 5) {
    return res.status(400).json({ msg: "يجب ان لا يقل اسم المدرس عن 6 حروف" });
  }

  // Validate description
  if (description.length < 9) {
    return res.status(400).json({ msg: "يجب ان لا يقل الوصف عن 10 حروف" });
  }

  // Validate branch
  const validBranches = [
    "Scientific",
    "Literary",
    "Math_Science",
    "Scientific_Sciences",
  ];
  if (!validBranches.includes(branch)) {
    return res.status(400).json({
      msg: "يجب ان تكون الشعبة علمي او ادبي او علمي علوم او علمي رياضة",
    });
  }

  try {
    const newCourse = new Course({
      subject,
      year,
      term,
      teacher,
      teacherImg,
      listOfLec,
      description,
      branch,
    });

    const savedCourse = await newCourse.save();
    res.status(201).json(savedCourse);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ msg: "Server error" });
  }
};

// Update a course
exports.updateCourse = async (req, res) => {
  const {
    subject,
    year,
    term,
    teacher,
    teacherImg,
    listOfLec,
    description,
    branch,
    suspend
  } = req.body;

  // Validate subject
  if (subject) {
    if (subject.length < 2) {
      return res.status(400).json({ msg: "يجب ان لا يقل الاسم عن 3 حروف" });
    }
  }

  // Validate year
  if (year) {
    const validYears = ["First", "Second", "Third"];
    if (!validYears.includes(year)) {
      return res.status(400).json({ msg: "يجب ادخال السنه الدراسية" });
    }
  }

  // Validate term
  if (term) {
    const validTerms = ["First", "Second"];
    if (!validTerms.includes(term)) {
      return res.status(400).json({ msg: "يجب ا��خال الفصل الدرا��ى" });
    }
  }

  // Validate teacher name
  if (teacher) {
    if (teacher.length < 5) {
      return res.status(400).json({ msg: "يجب ان لا يقل ا��م المدرس عن 6 حروف" });
    }
  }

  // Validate description
  if (description) {
    if (description.length < 9) {
      return res.status(400).json({ msg: "يجب ان لا يقل الوصف عن 10 حروف" });
    }
  }

  // Validate branch
  if (branch) {
    const validBranches = [
      "Scientific",
      "Literary",
      "Math_Science",
      "Scientific_Sciences",
    ];
    if (!validBranches.includes(branch)) {
      return res.status(400).json({
        msg: "يجب ان تكون الشعبة علمي او ا��بي او علمي علوم او علمي ريا��ة",
      });
    }
  }

  try {
    const updatedCourse = await Course.findByIdAndUpdate(
      req.params.id,
      {
        subject,
        year,
        term,
        teacher,
        teacherImg,
        listOfLec,
        description,
        branch,
        suspend,
      },
      { new: true, runValidators: true }
    );

    if (!updatedCourse) {
      return res.status(404).json({ msg: "هذا الكورس غير متوفر" });
    }

    res.status(200).json(updatedCourse);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ msg: "Server error" });
  }
};

// Delete a course
exports.deleteCourse = async (req, res) => {
  try {
    const deletedCourse = await Course.findByIdAndDelete(req.params.id);

    if (!deletedCourse) {
      return res.status(404).json({ msg: "هذا الكورس غير متاح" });
    }

    res.status(200).json({ msg: "تم حذف الكورس بنجاح" });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ msg: "Server error" });
  }
};

// Suspend a course
exports.suspendCourse = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) {
      return res.status(404).json({ msg: "هذا الكورس غير متاح" });
    }

    course.suspend = !course.suspend;
    await course.save();

    res.status(200).json({
      msg: `تم ${
        course.suspend ? "ايقاف" : "تفعيل"
      } الكورس بنجاح`,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ msg: "Server error" });
  }
};

// Add a lecture to a course
exports.addLecture = async (req, res) => {
  const { id } = req.params; 
  const { lectureLink } = req.body;

  // Ensure lecture link is provided
  if (!lectureLink) {
    return res.status(400).json({ msg: "يجب ادخال اللينك" });
  }

  try {
    const course = await Course.findById(id);
    if (!course) {
      return res.status(404).json({ msg: "هذا الكورس غير متاح" });
    }

    // Add lecture link to listOfLec array
    course.listOfLec.push(lectureLink);
    await course.save();

    res.status(200).json({ msg: "تم اضافه المحاضرة بنجاح", course });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ msg: "Server error" });
  }
};
