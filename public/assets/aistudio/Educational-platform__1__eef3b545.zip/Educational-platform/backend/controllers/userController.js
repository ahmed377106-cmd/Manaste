const { validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
require("dotenv").config();

// Login Controller
exports.login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ msg: "جميع الحقول مطلوبة" });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res
        .status(400)
        .json({ msg: "برجاء التأكد من كلمة السر و الايميل" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ msg: "برجاء التأكد من كلمة السر و الايميل" });
    }

    const payload = { userId: user.id };
    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: "5h",
    });

    res.json({ token });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};

// Signup Controller
exports.signup = async (req, res) => {
  const { name, email, password, branch, year, phone, fatherPhone, role } =
    req.body;

  // Set default role if not provided
  let userRole = role || "Student";

  // Check for required fields
  if (
    !name ||
    !email ||
    !password ||
    !branch ||
    !year ||
    !phone ||
    !fatherPhone
  ) {
    return res.status(400).json({ msg: "جميع الحقول مطلوبة" });
  }

  // Validate name
  if (name.length < 6) {
    return res.status(400).json({ msg: "يجب ان لا يقل الاسم عن 6 حروف" });
  }

  // Validate email
  if (!email.endsWith("@gmail.com")) {
    return res.status(400).json({ msg: "يجب ان يكون الايميل تابع للجيميل" });
  }

  // Validate password complexity
  const passwordComplexityRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if (!passwordComplexityRegex.test(password)) {
    return res.status(400).json({
      msg: "يجب أن تتكون كلمة المرور من 8 أحرف على الأقل وأن تحتوي على حرف واحد كبير على الأقل، وحرف صغير واحد على الأقل، ورقم واحد، ورمز خاص واحد.",
    });
  }

  // Validate branch
  const validBranches = [
    "Scientific",
    "Literary",
    "Math_Science",
    "Scientific_Sciences",
  ];
  if (!validBranches.includes(branch)) {
    return res.status(400).json({
      msg: "يجب ان تكون الشعبة علمي او ادبي او علمي علوم او علمي رياضة",
    });
  }

  // Validate year
  const validYears = ["First", "Second", "Third"];
  if (!validYears.includes(year)) {
    return res.status(400).json({ msg: "يجب ادخال السنه الدراسية" });
  }

  // Validate phone numbers
  const phoneRegex = /^01\d{9}$/;
  if (!phoneRegex.test(phone)) {
    return res.status(400).json({ msg: "برجاء ادخال رقم هاتف صحيح" });
  }
  if (!phoneRegex.test(fatherPhone)) {
    return res.status(400).json({ msg: "برجاء ادخال رقم هاتف صحيح للاب" });
  }

  // Validate role
  const validRoles = ["Admin", "Manager", "Student"];
  if (!validRoles.includes(userRole)) {
    return res
      .status(400)
      .json({ msg: " يجب ان يكون الدور اما المدير اما المسؤول اما الطالب" });
  }

  try {
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: "هذا الحساب موجود بالفعل" });
    }

    user = new User({
      name,
      email,
      password,
      branch,
      year,
      phone,
      fatherPhone,
      role: userRole,
    });

    await user.save();

    const payload = { userId: user.id };
    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: "5h",
    });

    res.status(201).json({ token });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};

// Get User Profile
exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user).select("-password");
    if (!user) {
      return res.status(404).json({ msg: "الحساب غير موجود" });
    }
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};

// Update User Profile  - next update
exports.updateProfile = async (req, res) => {
  const { name, email, password, branch, year } = req.body;

  const updatedFields = {};
  if (name) updatedFields.name = name;
  if (email) updatedFields.email = email;
  if (branch) updatedFields.branch = branch;
  if (year) updatedFields.year = year;
  if (password) {
    const salt = await bcrypt.genSalt(10);
    updatedFields.password = await bcrypt.hash(password, salt);
  }

  try {
    let user = await User.findById(req.user);
    if (!user) {
      return res.status(404).json({ msg: "User not found" });
    }

    user = await User.findByIdAndUpdate(
      req.user,
      { $set: updatedFields },
      { new: true }
    );

    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};

// Add Admin or manager
exports.addAdmin = async (req, res) => {
  const { name, email, password, phone, role } = req.body;


  // Check for required fields
  if (!name || !email || !password || !phone) {
    return res.status(400).json({ msg: "جميع الحقول مطلوبة" });
  }

  // Validate name
  if (name.length < 6) {
    return res.status(400).json({ msg: "يجب ان لا يقل الاسم عن 6 حروف" });
  }

  // Validate email
  if (!email.endsWith("@gmail.com")) {
    return res.status(400).json({ msg: "يجب ان يكون الايميل تابع للجيميل" });
  }

  // Validate password complexity
  const passwordComplexityRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if (!passwordComplexityRegex.test(password)) {
    return res.status(400).json({
      msg: "يجب أن تتكون كلمة المرور من 8 أحرف على الأقل وأن تحتوي على حرف واحد كبير على الأقل، وحرف صغير واحد على الأقل، ورقم واحد، ورمز خاص واحد.",
    });
  }


  // Validate phone numbers
  const phoneRegex = /^01\d{9}$/;
  if (!phoneRegex.test(phone)) {
    return res.status(400).json({ msg: "برجاء ادخال رقم هاتف صحيح" });
  }

  // Validate role
  const validRoles = ["Admin", "Manager"];
  if (!validRoles.includes(role)) {
    return res
      .status(400)
      .json({ msg: " يجب ان يكون الدور اما المدير اما المسؤول " });
  }

  try {
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: "هذا الحساب موجود بالفعل" });
    }

    user = new User({
      name,
      email,
      password,
      phone,
      role,
    });

    await user.save();

    const payload = { userId: user.id };
    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: "5h",
    });

    res.status(201).json({ token });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};

// Controller to get all admins and managers
exports.getAdminsAndManagers = async (req, res) => {
  try {
    const users = await User.find({ role: { $in: ["Admin", "Manager"] } });

    if (!users) {
      return res.status(404).json({ msg: "No admins or managers found" });
    }

    res.status(200).json(users);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};

// Controller to update the role of an existing admin or manager
exports.updateRole = async (req, res) => {
  const { userId, role } = req.body;

  // Validate role
  const validRoles = ["Admin", "Manager"];
  if (!validRoles.includes(role)) {
    return res.status(400).json({ msg: "Role must be either 'Admin' or 'Manager'" });
  }

  try {
    let user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ msg: "User not found" });
    }

    // Update user role
    user.role = role;
    await user.save();

    res.status(200).json({ msg: "Role updated successfully", user });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};


// Controller to delete an account (admin or manager)
exports.deleteAccount = async (req, res) => {
  const { userId } = req.params;

  try {
    let user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ msg: "User not found" });
    }

    // Use findByIdAndDelete to remove the user
    await User.findByIdAndDelete(userId);

    res.status(200).json({ msg: "Account deleted successfully" });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server error");
  }
};