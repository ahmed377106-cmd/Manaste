const Cart = require("../models/Cart");
const Course = require("../models/Course");
const User = require("../models/User");

// Get the cart for a user
exports.getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user }).populate(
      "courses.course"
    );
    if (!cart)
      return res.status(301).json({ message: "لا توجد كورسات بالعربة" });
    res.json(cart);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

// Add course to cart
exports.addToCart = async (req, res) => {
  const { courseId, userId } = req.body;

  // Validate userId and courseId
  if (!userId || !courseId) {
    return res.status(400).json({ message: "جميع الحقول مطلوبة" });
  }

  try {
    // Validate userId and courseId
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "هذا الطالب غير متاح" });

    const course = await Course.findById(courseId);
    if (!course)
      return res.status(404).json({ message: "هذا الكورس غير متاح" });

    // Find the user's cart
    let cart = await Cart.findOne({ user: userId });
    if (!cart) {
      cart = new Cart({ user: userId, courses: [] });
    }

    // Check if the course is already in the cart
    const existingCourse = cart.courses.find(
      (item) => item.course.toString() === courseId
    );
    if (existingCourse) {
      return res.status(301).json({ message: "هذا الكورس مضاف بالفعل" });
    }

    // Add new course to the cart
    cart.courses.push({ course: courseId });

    await cart.save();
    res.json(cart);
  } catch (error) {
    console.error("Error adding course to cart:", error); // Improved logging
    res.status(500).json({ message: "Server error" });
  }
};

// Remove course from cart
exports.removeFromCart = async (req, res) => {
  const { courseId } = req.params;

  try {
    const cart = await Cart.findOne({ user: req.user });
    if (!cart) return res.status(404).json({ message: "هذا الكورس غير متاح" });

    // Remove the course from the cart
    cart.courses = cart.courses.filter(
      (item) => item.course.toString() !== courseId
    );
    await cart.save();
    res.json(cart);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

// Accept a specific course in the cart
exports.acceptCart = async (req, res) => {
  const { courseId, cartId, userId } = req.body; // Get userId from request body

  try {
    // Find the cart by cartId
    const cart = await Cart.findById(cartId);
    if (!cart) return res.status(404).json({ message: "لا توجد عربة" });

    // Verify the userId matches the cart's user
    if (cart.user.toString() !== userId) {
      return res.status(403).json({ message: "لا يمكنك تعديل هذه العربة" });
    }

    // Find the course in the cart and update its status
    const course = cart.courses.find(
      (item) => item.course.toString() === courseId
    );
    if (!course) {
      return res.status(404).json({ message: "هذا الكورس غير موجود في العربة" });
    }

    // Update the status of the course to "Accepted"
    course.status = "Accepted";
    await cart.save();

    res.json(cart);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// Reject a specific course in the cart
exports.rejectCart = async (req, res) => {
  const { courseId, cartId, userId } = req.body; // Get userId from request body

  try {
    // Find the cart by cartId
    const cart = await Cart.findById(cartId);
    if (!cart) return res.status(404).json({ message: "لا توجد عربة" });

    // Verify the userId matches the cart's user
    if (cart.user.toString() !== userId) {
      return res.status(403).json({ message: "لا يمكنك تعديل هذه العربة" });
    }

    // Find the course in the cart and update its status
    const course = cart.courses.find(
      (item) => item.course.toString() === courseId
    );
    if (!course) {
      return res.status(404).json({ message: "هذا الكورس غير موجود في العربة" });
    }

    // Update the status of the course to "Rejected"
    course.status = "Rejected";
    await cart.save();

    res.json(cart);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// Get all waiting courses
exports.getWaitingCourses = async (req, res) => {
  
  try {
    // Find all carts and populate the courses and users
    const carts = await Cart.find().populate("courses.course").populate("user"); // Populate user field

    // Filter for courses with status "Waiting" and map to include user details and cartId
    const waitingCourses = carts.flatMap(cart =>
      cart.courses
        .filter(course => course.status === "Waiting" && course.course !== null)
        .map(course => ({
          user: cart.user, // Include all user information
          course: course.course,
          cartId: cart._id // Include cartId in the response
        }))
    );

    if (waitingCourses.length === 0) {
      return res.status(404).json({ message: "لا توجد كورسات في حالة الانتظار" });
    }

    res.json(waitingCourses);
  } catch (error) {
    console.error("Error fetching waiting courses:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Get all carts (Admin/Manager only)
exports.getAllCarts = async (req, res) => {
  try {
    const user = await User.findById(req.user);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    if (user.role !== "Admin" && user.role !== "Manager") {
      return res.status(403).json({ message: "Access denied" });
    }

    const carts = await Cart.find().populate("user").populate("courses.course");

    res.json(carts);
  } catch (error) {
    console.error("Error fetching carts:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// Generalized controller to update course status (Admin/Manager only)
exports.updateCartStatus = async (req, res) => {
  const { courseId, cartId, status } = req.body; // Receive courseId, cartId, and status from request body

  try {

    const user = await User.findById(req.user);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    if (user.role !== "Admin" && user.role !== "Manager") {
      return res.status(403).json({ message: "Access denied" });
    }
    
    const cart = await Cart.findById(cartId);
    if (!cart) return res.status(404).json({ message: "لا توجد عربة" });

    const course = cart.courses.find(
      (item) => item.course.toString() === courseId
    );
    if (!course) {
      return res.status(404).json({ message: "هذا الكورس غير موجود في العربة" });
    }

    course.status = status;

    await cart.save();

    res.json(cart);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};
