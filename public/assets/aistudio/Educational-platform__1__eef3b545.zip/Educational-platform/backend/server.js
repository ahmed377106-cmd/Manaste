require('dotenv').config();
const cors = require('cors');
const express = require('express');
const mongoose = require('mongoose');
const db = require('./config/db');
const authRouter = require('./routes/auth');
const courseRouter = require("./routes/courseRouter");
const cartRoutes = require("./routes/cartRouter");

const app = express();
const PORT = process.env.PORT || 5000;

// CORS configuration for all origins
app.use(
  cors({
    origin: '*', 
    methods: ["GET", "POST", "PATCH", "PUT", "DELETE"],
    credentials: true,
  })
);

// Middleware
app.use(express.json());

// Routes
app.use('/api/auth', authRouter);
app.use("/api/courses", courseRouter);
app.use("/api/cart", cartRoutes);

// Connect to MongoDB
db.connect();

// Start server
app.listen(PORT, (err) => {
  if (err) {
    console.error(`Failed to start server: ${err}`);
    process.exit(1);
  } else {
    console.log(`Server running on port ${PORT}`);
  }
});
