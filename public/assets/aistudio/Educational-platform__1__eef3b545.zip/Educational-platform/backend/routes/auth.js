const express = require('express');
const { check } = require('express-validator');
const auth = require('../middleware/auth'); 
const { signup, login, getProfile, updateProfile, addAdmin, getAdminsAndManagers, deleteAccount, updateRole } = require('../controllers/userController.js');
const router = express.Router();

// Signup route with validation
router.post('/signup',
    [
        check('name', 'Name is required').not().isEmpty(),
        check('email', 'Please include a valid email').isEmail(),
        check('password', 'Password must be at least 8 characters long').isLength({ min: 8 }),
        check('phone', 'Phone number must be exactly 11 digits long').isLength({ min: 11, max: 11 }).isNumeric(),
        check('fatherPhone', "Father's phone number must be exactly 11 digits long").isLength({ min: 11, max: 11 }).isNumeric(),
        check('branch', 'Branch is required and must be one of: Scientific, Literary, Math_Science, Scientific_Sciences').isIn(["Scientific", "Literary", "Math_Science", "Scientific_Sciences"]),
        check('year', 'Year is required and must be one of: First, Second, Third').isIn(["First", "Second", "Third"]),
    ],
    signup
);

// Add Admin or Manager 
router.post('/addadmin',
    [
        check('name', 'Name is required').not().isEmpty(),
        check('email', 'Please include a valid email').isEmail(),
        check('password', 'Password must be at least 8 characters long').isLength({ min: 8 }),
        check('phone', 'Phone number must be exactly 11 digits long').isLength({ min: 11, max: 11 }).isNumeric(),
    ],
    addAdmin
);

// Route to get all admins and managers
router.get('/getadmins', getAdminsAndManagers);

// Route to update role of an admin or manager
router.put('/updateRole', 
    [
        check('userId', 'User ID is required').not().isEmpty(),
        check('role', 'Role is required').not().isEmpty(),
    ],
    updateRole
);

// Route to delete an account (admin or manager)
router.delete('/deleteAccount/:userId', deleteAccount);

// Login route with validation
router.post( '/login',
    [
        check('email', 'Please include a valid email').isEmail(),
        check('password', 'Password is required').exists()
    ],
    login
);

// Get user profile (Protected)
router.get('/profile', auth, getProfile);

// Update user profile (Protected)
router.put('/profile', auth, updateProfile);

module.exports = router;
