const express = require("express");
const { getWaitingCourses, getCart, addToCart, removeFromCart, acceptCart, rejectCart, getAllCarts, updateCartStatus } = require("../controllers/cartController.js");
const auth = require('../middleware/auth'); 

const router = express.Router();

// Get cart for the authenticated user
router.get("/", auth, getCart);

// Add course to cart
router.post("/", auth, addToCart);

// Remove course from cart
router.delete("/:courseId", auth, removeFromCart);

// Accept cart route
router.patch("/accept", auth, acceptCart);

// Reject cart route
router.patch("/reject", auth, rejectCart);

// Get all waiting courses from all users
router.get("/waiting", auth, getWaitingCourses);

// Route to get all carts (Admin/Manager only)
router.get("/all", auth, getAllCarts);

// Route to update course status for Admin/Manager only
router.patch("/update-status", auth, updateCartStatus);


module.exports = router;
