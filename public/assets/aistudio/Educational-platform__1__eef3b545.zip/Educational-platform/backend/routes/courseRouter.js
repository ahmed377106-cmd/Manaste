const express = require("express");
const router = express.Router();
const courseController = require("../controllers/courseController");

// Routes
router.get("/", courseController.getAllCourses);                           //✅
router.get("/:id", courseController.getCourseById);                        //✅
router.post("/", courseController.addCourse);                              //✅
router.put("/:id", courseController.updateCourse);                         //✅
router.delete("/:id", courseController.deleteCourse);                      //✅
router.patch("/:id/suspend", courseController.suspendCourse);              //✅
router.patch("/:id/add-lecture", courseController.addLecture);             //✅

module.exports = router;
